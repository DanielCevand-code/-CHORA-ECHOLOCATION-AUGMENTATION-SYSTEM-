#!/bin/bash
# Chōra — Run All Tests
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$SCRIPT_DIR/.."

echo "══════════════════════════════════════════"
echo "  Chōra — Test Suite"
echo "══════════════════════════════════════════"

cd "$ROOT_DIR"

# Run Python tests
echo ""
echo "Running unit tests..."
python3 -m pytest tests/unit/ -v

echo ""
echo "All tests passed."
