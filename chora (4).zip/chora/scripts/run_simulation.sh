#!/bin/bash
# Chōra — Run Python Simulation
# Usage: ./run_simulation.sh [--week N] [--visualize] [--clicks N]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SIM_DIR="$SCRIPT_DIR/../simulation"

echo "══════════════════════════════════════════"
echo "  Chōra — Pipeline Simulation"
echo "══════════════════════════════════════════"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: python3 not found. Install Python 3.10+"
    exit 1
fi

# Install dependencies if needed
if ! python3 -c "import numpy" 2>/dev/null; then
    echo "Installing dependencies..."
    pip install -r "$SIM_DIR/requirements.txt"
fi

# Run simulation
cd "$SIM_DIR"
python3 chora_sim.py "$@"
