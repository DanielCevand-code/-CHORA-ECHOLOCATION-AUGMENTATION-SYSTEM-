/**
 * Chōra — Hardware Abstraction Layer (HAL)
 * 
 * Platform-independent interfaces for all hardware peripherals.
 * Implementations are board-specific (see boards/alif_e7/).
 * 
 * This HAL allows the same DSP code to run on:
 *   - Alif Ensemble E7 (production target)
 *   - Raspberry Pi Zero 2W (Phase 0 research prototype)
 *   - Desktop simulation (testing)
 */

#ifndef CHORA_HAL_H
#define CHORA_HAL_H

#include <stdint.h>
#include <stdbool.h>

/* ═══════════════════════════════════════════════════════════
 * TIMING
 * ═══════════════════════════════════════════════════════════ */

/** Get current time in microseconds (32-bit, wraps at ~71 minutes) */
uint32_t ss_get_time_us(void);

/** Blocking delay in microseconds */
void ss_delay_us(uint32_t us);

/** Yield to RTOS scheduler */
void ss_thread_yield(void);

/* ═══════════════════════════════════════════════════════════
 * GPIO
 * ═══════════════════════════════════════════════════════════ */

#define GPIO_INPUT   0
#define GPIO_OUTPUT  1

void ss_gpio_configure(int pin, int direction);
void ss_gpio_write(int pin, int value);
int  ss_gpio_read(int pin);

/* ═══════════════════════════════════════════════════════════
 * SPI (LiDAR sensors)
 * ═══════════════════════════════════════════════════════════ */

void ss_spi_init(int bus, uint32_t clock_hz);
int  ss_spi_transfer(int bus, const uint8_t* tx, uint8_t* rx, int len);

/* ═══════════════════════════════════════════════════════════
 * I2C (IMU: Bosch BMI270)
 * ═══════════════════════════════════════════════════════════ */

void ss_i2c_init(int bus, uint32_t clock_hz);
int  ss_i2c_read(uint8_t addr, uint8_t reg, uint8_t* data, int len);
int  ss_i2c_write(uint8_t addr, uint8_t reg, const uint8_t* data, int len);

/* ═══════════════════════════════════════════════════════════
 * ADC (MEMS ultrasonic RX capture)
 * ═══════════════════════════════════════════════════════════ */

void ss_adc_init(int channel, uint32_t sample_rate);
void ss_adc_capture_dma(int channel, float* buffer, int count);
void ss_adc_wait_complete(void);

/* ═══════════════════════════════════════════════════════════
 * DAC (MEMS ultrasonic TX chirp output)
 * ═══════════════════════════════════════════════════════════ */

void ss_dac_init(int channel);
void ss_dac_write(int channel, uint16_t value);

/* ═══════════════════════════════════════════════════════════
 * PWM (Haptic actuators on wristband)
 * ═══════════════════════════════════════════════════════════ */

void ss_pwm_init(int module, int channel, uint32_t period_us);
void ss_pwm_set(int module, int channel, uint32_t period_us, uint32_t duty_us);

/* ═══════════════════════════════════════════════════════════
 * PDM (MEMS Microphone interface)
 * ═══════════════════════════════════════════════════════════ */

typedef void (*pdm_callback_t)(const float* samples, int count);

void ss_pdm_init(int clk_pin, int data_pin, uint32_t sample_rate, int ratio);
void ss_pdm_set_callback(pdm_callback_t cb, int block_size);

/* ═══════════════════════════════════════════════════════════
 * I2S (Bone conduction audio output)
 * ═══════════════════════════════════════════════════════════ */

void ss_i2s_init(uint32_t sample_rate, int bits, int channels);
void ss_i2s_dma_start(const float* left, const float* right, int count);

/* ═══════════════════════════════════════════════════════════
 * BLE (Nordic nRF5340 — wristband link + fleet uplink)
 * ═══════════════════════════════════════════════════════════ */

int  ss_ble_init(void);
int  ss_ble_notify(uint16_t char_uuid, const uint8_t* data, int len);
int  ss_ble_send_fleet_data(const void* data, int len);
bool ss_ble_is_connected(void);

/* ═══════════════════════════════════════════════════════════
 * LOGGING
 * ═══════════════════════════════════════════════════════════ */

void ss_log(const char* fmt, ...);

#endif /* CHORA_HAL_H */
