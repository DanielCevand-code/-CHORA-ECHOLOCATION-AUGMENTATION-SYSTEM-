/**
 * Chōra — Core Pipeline Types
 * 
 * Central data structures for the echolocation augmentation pipeline.
 * All sensor data flows through these types from capture → DSP → output.
 * 
 * Pipeline budget: 8ms total (click → augmented echo output)
 * Target: ARM Cortex-M55 + Ethos-U55 NPU @ 800MHz
 */

#ifndef CHORA_CORE_PIPELINE_H
#define CHORA_CORE_PIPELINE_H

#include <stdint.h>
#include <stdbool.h>
#include <math.h>

/* ═══════════════════════════════════════════════════════════
 * PHYSICAL CONSTANTS
 * ═══════════════════════════════════════════════════════════ */

#define SPEED_OF_SOUND_MS       343.0f    /* m/s at 20°C */
#define ULTRASONIC_FREQ_HZ      40000     /* MEMS transducer center freq */
#define LIDAR_RANGE_M           15.0f     /* Max detection range */
#define LIDAR_FPS               20        /* Point cloud frames per second */
#define SAMPLE_RATE_HZ          48000     /* Audio sample rate */
#define PIPELINE_BUDGET_MS      8.0f      /* Total click→output budget */
#define AUDITORY_FUSION_MS      10.0f     /* Brain fusion threshold */
#define HAPTIC_UPDATE_HZ        60        /* Wristband refresh rate */

/* ═══════════════════════════════════════════════════════════
 * POINT CLOUD STRUCTURES
 * ═══════════════════════════════════════════════════════════ */

/** Single 3D point from LiDAR return */
typedef struct {
    float x, y, z;          /* Position in device frame (meters) */
    float intensity;        /* Return intensity (0.0–1.0) */
    float distance;         /* Range from sensor (meters) */
    uint8_t ring_id;        /* LiDAR scan ring index */
} ss_point3d_t;

/** Point cloud frame — one complete LiDAR scan */
typedef struct {
    ss_point3d_t  points[2048];   /* Max points per frame */
    uint16_t      count;          /* Actual number of valid points */
    uint32_t      timestamp_us;   /* Microsecond timestamp */
    float         scan_angle_rad; /* Current scan orientation */
} ss_point_cloud_t;

/** Voxel grid cell for spatial occupancy */
typedef struct {
    float  occupancy;       /* 0.0 = empty, 1.0 = solid */
    float  reflectivity;    /* Acoustic reflectivity estimate */
    uint8_t material_id;    /* Classified material type */
} ss_voxel_t;

/** Voxel grid — 3D spatial occupancy map */
#define VOXEL_GRID_X    30
#define VOXEL_GRID_Y    30
#define VOXEL_GRID_Z    10
#define VOXEL_SIZE_M    0.5f

typedef struct {
    ss_voxel_t cells[VOXEL_GRID_X][VOXEL_GRID_Y][VOXEL_GRID_Z];
    float      origin_x, origin_y, origin_z;
    uint32_t   frame_id;
} ss_voxel_grid_t;

/* ═══════════════════════════════════════════════════════════
 * MATERIAL CLASSIFICATION
 * ═══════════════════════════════════════════════════════════ */

typedef enum {
    MAT_UNKNOWN   = 0,
    MAT_CONCRETE  = 1,   /* α ≈ 0.02 — strong low-freq reflection */
    MAT_STONE     = 2,   /* α ≈ 0.03 — deep rumble return */
    MAT_WOOD      = 3,   /* α ≈ 0.10 — warm mid-freq resonance */
    MAT_GLASS     = 4,   /* α ≈ 0.04 — crisp high-freq shimmer */
    MAT_METAL     = 5,   /* α ≈ 0.02 — sharp ringing return */
    MAT_FOLIAGE   = 6,   /* α ≈ 0.50 — diffuse absorption */
    MAT_WATER     = 7,   /* α ≈ 0.01 — bright scatter */
    MAT_FABRIC    = 8,   /* α ≈ 0.40 — heavy absorption */
    MAT_HUMAN     = 9,   /* α ≈ 0.30 — soft mid-band absorption */
    MAT_COUNT
} ss_material_t;

/** Acoustic properties per material */
typedef struct {
    float absorption_coeff;     /* α: 0.0 = perfect reflector */
    float freq_band_low;        /* Lower frequency response (Hz) */
    float freq_band_high;       /* Upper frequency response (Hz) */
    float scatter_coeff;        /* Diffusion factor */
    const char* name;
} ss_material_props_t;

/* ═══════════════════════════════════════════════════════════
 * ACOUSTIC GRAMMAR — THE FOUR EQUATIONS
 * ═══════════════════════════════════════════════════════════ */

/** Echo return from a single surface */
typedef struct {
    float distance_m;       /* d = c·Δτ/2 — Equation 1 */
    float azimuth_rad;      /* Angle from forward axis */
    float elevation_rad;    /* Vertical angle */
    float amplitude;        /* Return amplitude after attenuation */
    float attenuation;      /* α(f) — Equation 2 */
    ss_material_t material; /* Classified surface material */
    float delay_s;          /* Round-trip time */
} ss_echo_return_t;

/** Complete echo field from one click event */
typedef struct {
    ss_echo_return_t  returns[256];   /* Individual echo returns */
    uint16_t          count;          /* Number of valid returns */
    float             harmonic_field; /* Hᵢ — Equation 3: interference */
    float             atmo_factor;    /* α(f,H) — Equation 4: humidity */
    uint32_t          click_time_us;  /* Click onset timestamp */
    float             temperature_c;  /* Ambient temperature */
    float             humidity_pct;   /* Relative humidity */
} ss_echo_field_t;

/* ═══════════════════════════════════════════════════════════
 * CLICK DETECTION
 * ═══════════════════════════════════════════════════════════ */

typedef enum {
    CLICK_NONE     = 0,
    CLICK_TONGUE   = 1,   /* Palatal click — sharp transient */
    CLICK_MOUTH    = 2,   /* Mouth click — broader spectrum */
    CLICK_FINGER   = 3,   /* Finger snap — highest energy */
} ss_click_type_t;

typedef struct {
    ss_click_type_t type;
    uint32_t        onset_time_us;   /* Microsecond precision */
    float           energy;          /* RMS energy of the click */
    float           peak_freq_hz;    /* Dominant frequency */
    float           duration_ms;     /* Click duration */
    bool            is_valid;        /* Passes quality threshold */
} ss_click_event_t;

/* ═══════════════════════════════════════════════════════════
 * HAPTIC OUTPUT — 3×3 WRISTBAND GRID
 * ═══════════════════════════════════════════════════════════ */

/**
 * Grid layout (from user's perspective):
 *   [Far-L]  [Far-C]  [Far-R]     Row 0: 160–250m range
 *   [Mid-L]  [Mid-C]  [Mid-R]     Row 1: 80–160m range
 *   [Near-L] [Near-C] [Near-R]    Row 2: 0–80m range
 * 
 * Columns: Left / Center / Right azimuth sectors
 */

#define HAPTIC_ROWS     3
#define HAPTIC_COLS     3
#define HAPTIC_CELLS    (HAPTIC_ROWS * HAPTIC_COLS)

typedef struct {
    float intensity;    /* 0.0–1.0 vibration amplitude */
    float frequency;    /* Vibration frequency (Hz) */
    uint8_t pattern;    /* Vibration pattern (texture encoding) */
} ss_haptic_cell_t;

typedef struct {
    ss_haptic_cell_t cells[HAPTIC_ROWS][HAPTIC_COLS];
    uint32_t         timestamp_us;
    float            augmentation_level;  /* Training scaffold: 0.0–1.0 */
} ss_haptic_frame_t;

/* ═══════════════════════════════════════════════════════════
 * AUDIO OUTPUT — BINAURAL BONE CONDUCTION
 * ═══════════════════════════════════════════════════════════ */

#define AUDIO_BLOCK_SIZE    256    /* Samples per processing block */
#define AUDIO_CHANNELS      2     /* Left + right bone conduction */

typedef struct {
    float left[AUDIO_BLOCK_SIZE];    /* Left cheekbone driver */
    float right[AUDIO_BLOCK_SIZE];   /* Right cheekbone driver */
    uint32_t timestamp_us;
} ss_audio_frame_t;

/** HRTF filter coefficients (per direction) */
typedef struct {
    float left_fir[128];     /* Left ear impulse response */
    float right_fir[128];    /* Right ear impulse response */
    float azimuth_rad;       /* Direction this HRTF represents */
    float elevation_rad;
} ss_hrtf_entry_t;

/* ═══════════════════════════════════════════════════════════
 * IMU — HEAD ORIENTATION
 * ═══════════════════════════════════════════════════════════ */

typedef struct {
    float accel_x, accel_y, accel_z;   /* Accelerometer (m/s²) */
    float gyro_x, gyro_y, gyro_z;      /* Gyroscope (rad/s) */
    float yaw, pitch, roll;            /* Fused orientation (rad) */
    uint32_t timestamp_us;
} ss_imu_data_t;

/* ═══════════════════════════════════════════════════════════
 * TRAINING SCAFFOLD — DIKW PROGRESSION
 * ═══════════════════════════════════════════════════════════ */

typedef enum {
    DIKW_DATA        = 0,   /* Weeks 1–2: raw signal exposure */
    DIKW_INFORMATION = 1,   /* Weeks 3–5: structured patterns */
    DIKW_KNOWLEDGE   = 2,   /* Weeks 6–8: internalized model */
    DIKW_WISDOM      = 3,   /* Weeks 9–10: autonomous navigation */
} ss_dikw_level_t;

typedef struct {
    uint8_t          current_week;         /* 1–10 */
    ss_dikw_level_t  level;                /* Current DIKW stage */
    float            augmentation;         /* 0.0–1.0 output scaling */
    float            click_accuracy;       /* User's discrimination score */
    float            spatial_resolution;   /* Angular discrimination (rad) */
    uint32_t         total_clicks;         /* Lifetime click count */
    uint32_t         session_clicks;       /* This session */
    float            v1_activation_est;    /* Estimated cortical response */
} ss_training_state_t;

/* ═══════════════════════════════════════════════════════════
 * PIPELINE STATE — MASTER STRUCTURE
 * ═══════════════════════════════════════════════════════════ */

typedef struct {
    /* Sensor inputs */
    ss_point_cloud_t    point_cloud;
    ss_click_event_t    last_click;
    ss_imu_data_t       imu;
    
    /* Processing results */
    ss_voxel_grid_t     voxel_grid;
    ss_echo_field_t     echo_field;
    
    /* Outputs */
    ss_haptic_frame_t   haptic;
    ss_audio_frame_t    audio;
    
    /* State */
    ss_training_state_t training;
    
    /* Timing */
    uint32_t pipeline_start_us;
    uint32_t pipeline_end_us;
    float    pipeline_latency_ms;
    
    /* System */
    bool     is_running;
    bool     click_pending;
    float    battery_pct;
    float    temperature_c;
    float    humidity_pct;
} ss_pipeline_t;

/* ═══════════════════════════════════════════════════════════
 * FUNCTION PROTOTYPES — PIPELINE STAGES
 * ═══════════════════════════════════════════════════════════ */

/* Initialization */
int  ss_pipeline_init(ss_pipeline_t* p);
void ss_pipeline_reset(ss_pipeline_t* p);

/* Pipeline execution (called per click event) */
int  ss_pipeline_run(ss_pipeline_t* p);

/* Individual stage functions */
int  ss_click_detect(ss_pipeline_t* p);         /* Stage 1: 0.5ms */
int  ss_lidar_capture(ss_pipeline_t* p);        /* Stage 2: 2.0ms */
int  ss_ray_cast(ss_pipeline_t* p);             /* Stage 3: 1.0ms */
int  ss_material_classify(ss_pipeline_t* p);    /* Stage 4: 1.0ms */
int  ss_rir_synthesize(ss_pipeline_t* p);       /* Stage 5: 1.5ms */
int  ss_hrtf_render(ss_pipeline_t* p);          /* Stage 6: 1.0ms */
int  ss_bone_output(ss_pipeline_t* p);          /* Stage 7: 0.5ms */
int  ss_haptic_map(ss_pipeline_t* p);           /* Stage 8: 0.5ms */

#endif /* CHORA_CORE_PIPELINE_H */
