"""
Chōra — Acoustic Grammar Unit Tests

Verifies the four core equations produce physically correct results.
"""

import pytest
import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "simulation"))
from acoustic_grammar import (
    echo_distance, atmospheric_attenuation,
    harmonic_interference, environmental_channel,
    compute_three_band_spectrum, classify_material,
    ray_cast_2d, Obstacle, Material, EchoReturn,
    SPEED_OF_SOUND
)


class TestEquation1_EchoDistance:
    """d = c · Δτ / 2"""
    
    def test_known_distance(self):
        """1 meter at 20°C: delay = 2×1/343 = 0.005831s"""
        delay = 2.0 * 1.0 / 343.0
        d = echo_distance(delay, temperature_c=20.0)
        assert abs(d - 1.0) < 0.01
    
    def test_zero_delay(self):
        assert echo_distance(0.0) == 0.0
    
    def test_temperature_correction(self):
        """Higher temp → faster sound → shorter measured distance for same delay."""
        delay = 0.01  # Fixed delay
        d_cold = echo_distance(delay, temperature_c=0.0)
        d_hot = echo_distance(delay, temperature_c=40.0)
        assert d_hot > d_cold
    
    def test_speed_of_sound_at_20c(self):
        """c = 331.3 + 0.606 × 20 = 343.42 m/s"""
        c = 331.3 + 0.606 * 20.0
        assert abs(c - 343.42) < 0.01


class TestEquation2_AtmosphericAttenuation:
    """α(f) = 1.17 × 10⁻⁵ · f²"""
    
    def test_low_freq_low_attenuation(self):
        """Low frequencies should attenuate very little."""
        atten = atmospheric_attenuation(250.0, 5.0)
        assert atten > 0.5  # Low freq still retains majority of energy
    
    def test_high_freq_more_attenuation(self):
        """Higher frequencies should attenuate more."""
        atten_low = atmospheric_attenuation(500.0, 10.0)
        atten_high = atmospheric_attenuation(4000.0, 10.0)
        assert atten_high < atten_low
    
    def test_distance_increases_attenuation(self):
        atten_near = atmospheric_attenuation(2000.0, 1.0)
        atten_far = atmospheric_attenuation(2000.0, 10.0)
        assert atten_far < atten_near
    
    def test_zero_distance_no_attenuation(self):
        atten = atmospheric_attenuation(4000.0, 0.0)
        assert abs(atten - 1.0) < 0.001


class TestEquation3_HarmonicInterference:
    """Hᵢ = |Σ Aⱼ · e^(iφⱼ)|"""
    
    def test_single_echo(self):
        """Single echo → interference magnitude equals amplitude."""
        echoes = [EchoReturn(
            distance=5.0, azimuth=0.0, elevation=0.0,
            amplitude=1.0, attenuation=1.0,
            material=Material.CONCRETE, delay=0.029
        )]
        H = harmonic_interference(echoes, 1000.0)
        assert abs(H - 1.0) < 0.01
    
    def test_constructive_interference(self):
        """Two in-phase echoes → constructive interference (amplitude doubles)."""
        freq = 1000.0
        delay = 1.0 / freq  # Exactly one period delay difference
        echoes = [
            EchoReturn(distance=1.0, azimuth=0, elevation=0,
                       amplitude=1.0, attenuation=1.0,
                       material=Material.CONCRETE, delay=0.0),
            EchoReturn(distance=1.0, azimuth=0, elevation=0,
                       amplitude=1.0, attenuation=1.0,
                       material=Material.CONCRETE, delay=delay),
        ]
        H = harmonic_interference(echoes, freq)
        assert H > 1.8  # Should be ~2.0
    
    def test_destructive_interference(self):
        """Two anti-phase echoes → destructive interference."""
        freq = 1000.0
        delay = 0.5 / freq  # Half-period delay
        echoes = [
            EchoReturn(distance=1.0, azimuth=0, elevation=0,
                       amplitude=1.0, attenuation=1.0,
                       material=Material.CONCRETE, delay=0.0),
            EchoReturn(distance=1.0, azimuth=0, elevation=0,
                       amplitude=1.0, attenuation=1.0,
                       material=Material.CONCRETE, delay=delay),
        ]
        H = harmonic_interference(echoes, freq)
        assert H < 0.2  # Should be ~0.0
    
    def test_empty_returns_zero(self):
        assert harmonic_interference([], 1000.0) == 0.0


class TestEquation4_EnvironmentalChannel:
    """α(f,H) = k · f² · e^(−βH)"""
    
    def test_dry_air_higher_attenuation(self):
        """Dry air (low humidity) → more high-freq attenuation."""
        atten_dry = environmental_channel(4000.0, 20.0)
        atten_humid = environmental_channel(4000.0, 80.0)
        assert atten_dry > atten_humid
    
    def test_frequency_squared_dependency(self):
        """Doubling frequency → roughly 4× attenuation."""
        a1 = environmental_channel(1000.0, 50.0)
        a2 = environmental_channel(2000.0, 50.0)
        ratio = a2 / a1
        assert abs(ratio - 4.0) < 0.5


class TestRayCasting:
    """Integration test: ray casting through obstacles."""
    
    def test_detects_obstacle_ahead(self):
        obstacles = [
            Obstacle(4.0, -0.5, 1.0, 1.0, Material.CONCRETE, "Wall")
        ]
        field = ray_cast_2d(
            origin=np.array([0.0, 0.0]),
            heading=0.0,
            obstacles=obstacles
        )
        assert len(field.returns) > 0
        # Should detect wall at ~4m
        distances = [e.distance for e in field.returns]
        assert min(distances) < 5.0
    
    def test_nothing_behind(self):
        """Obstacle behind user should not be detected."""
        obstacles = [
            Obstacle(-5.0, -0.5, 1.0, 1.0, Material.CONCRETE, "Behind")
        ]
        field = ray_cast_2d(
            origin=np.array([0.0, 0.0]),
            heading=0.0,  # Facing +x
            obstacles=obstacles
        )
        # Should detect nothing (obstacle is at -x)
        forward_hits = [e for e in field.returns if abs(e.azimuth) < 0.5]
        assert len(forward_hits) == 0

    def test_three_band_spectrum_computed(self):
        obstacles = [
            Obstacle(3.0, -0.5, 1.0, 1.0, Material.GLASS, "Glass"),
            Obstacle(2.0, 1.0, 1.0, 1.0, Material.STONE, "Stone"),
        ]
        field = ray_cast_2d(
            origin=np.array([0.0, 0.0]),
            heading=0.0,
            obstacles=obstacles
        )
        assert field.band_low >= 0
        assert field.band_mid >= 0
        assert field.band_high >= 0


class TestThreeBandSpectrum:
    """Verify three-band decomposition."""
    
    def test_glass_has_high_band_energy(self):
        """Glass (2000–8000 Hz) should produce high-band energy."""
        echoes = [EchoReturn(
            distance=3.0, azimuth=0, elevation=0,
            amplitude=0.5, attenuation=0.9,
            material=Material.GLASS,
            delay=2 * 3.0 / SPEED_OF_SOUND
        )]
        low, mid, high = compute_three_band_spectrum(echoes)
        # Glass should have relatively more high-band energy
        assert high > 0
    
    def test_stone_has_low_band_energy(self):
        """Stone (100–600 Hz) should produce low-band energy."""
        echoes = [EchoReturn(
            distance=3.0, azimuth=0, elevation=0,
            amplitude=0.5, attenuation=0.9,
            material=Material.STONE,
            delay=2 * 3.0 / SPEED_OF_SOUND
        )]
        low, mid, high = compute_three_band_spectrum(echoes)
        assert low > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
