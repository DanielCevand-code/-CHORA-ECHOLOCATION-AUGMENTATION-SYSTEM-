/**
 * Chōra — Main Pipeline Orchestrator
 * 
 * This is the application entry point that ties every component together.
 * It runs the real-time 8ms pipeline loop:
 * 
 *   [Click Detect] → [LiDAR Capture] → [Ray Cast] → [Material ID]
 *        0.5ms           2.0ms           1.0ms         1.0ms
 *   
 *   → [RIR Synthesis] → [HRTF Render] → [Bone Output] + [Haptic Map]
 *        1.5ms             1.0ms           0.5ms          0.5ms
 * 
 * Total: 8.0ms — below 10ms auditory fusion threshold.
 * 
 * The brain cannot distinguish augmented echo from natural echo.
 * That is the engineering requirement that makes cortical training work.
 * 
 * Platform: Zephyr RTOS on Alif Ensemble E7 (ARM Cortex-M55 + Ethos-U55)
 */

#include "core/pipeline.h"
#include "drivers/lidar.h"
#include "drivers/mems.h"
#include "dsp/acoustic_grammar.h"
#include "dsp/rir_engine.h"
#include "haptic/haptic_mapper.h"
#include "training/scaffold.h"
#include <string.h>

/* ═══════════════════════════════════════════════════════════
 * GLOBAL PIPELINE STATE
 * ═══════════════════════════════════════════════════════════ */

static ss_pipeline_t pipeline;

/* Audio output double-buffer (ping-pong) */
static ss_audio_frame_t audio_buf_a, audio_buf_b;
static volatile int active_audio_buf = 0;

/* Microphone input buffer */
#define MIC_BLOCK_SIZE 128
static float mic_input_block[MIC_BLOCK_SIZE];

/* ═══════════════════════════════════════════════════════════
 * BONE CONDUCTION AUDIO OUTPUT (I2S / PWM Driver)
 * ═══════════════════════════════════════════════════════════ */

/**
 * Audio output via I2S to bone conduction piezo drivers.
 * Uses double-buffering: while one buffer plays, the other fills.
 * 
 * Left channel  → left cheekbone driver (Knowles BU-27135)
 * Right channel → right cheekbone driver
 */
static void audio_output_init(void) {
    /* Configure I2S peripheral */
    /* I2S clock: 48kHz × 16bit × 2ch = 1.536MHz bit clock */
    ss_i2s_init(SAMPLE_RATE_HZ, 16, 2);
    
    /* Enable DMA for continuous output */
    ss_i2s_dma_start(audio_buf_a.left, audio_buf_a.right, AUDIO_BLOCK_SIZE);
}

/**
 * DMA completion interrupt — swap buffers and continue output.
 * Called every AUDIO_BLOCK_SIZE / SAMPLE_RATE = 5.33ms
 */
void audio_dma_complete_isr(void) {
    active_audio_buf ^= 1;
    ss_audio_frame_t* next = (active_audio_buf == 0) ? &audio_buf_a : &audio_buf_b;
    ss_i2s_dma_start(next->left, next->right, AUDIO_BLOCK_SIZE);
}

/**
 * Write processed audio to the inactive buffer.
 * The DMA will pick it up on the next swap.
 */
static void audio_output_write(const ss_audio_frame_t* frame) {
    ss_audio_frame_t* target = (active_audio_buf == 0) ? &audio_buf_b : &audio_buf_a;
    memcpy(target->left, frame->left, AUDIO_BLOCK_SIZE * sizeof(float));
    memcpy(target->right, frame->right, AUDIO_BLOCK_SIZE * sizeof(float));
}

/* ═══════════════════════════════════════════════════════════
 * IMU DRIVER (Bosch BMI270)
 * ═══════════════════════════════════════════════════════════ */

/**
 * Read 6-axis IMU data and compute fused orientation.
 * Head yaw/pitch/roll are used to orient the LiDAR scan
 * and HRTF spatialization.
 */
static void imu_read(ss_imu_data_t* data) {
    /* Read raw accelerometer and gyroscope via I2C */
    int16_t raw[6];
    ss_i2c_read(0x68, 0x0C, (uint8_t*)raw, 12);
    
    /* Convert to physical units */
    data->accel_x = (float)raw[0] / 16384.0f * 9.81f;  /* ±2g range */
    data->accel_y = (float)raw[1] / 16384.0f * 9.81f;
    data->accel_z = (float)raw[2] / 16384.0f * 9.81f;
    data->gyro_x  = (float)raw[3] / 131.0f * (M_PI / 180.0f);  /* ±250°/s */
    data->gyro_y  = (float)raw[4] / 131.0f * (M_PI / 180.0f);
    data->gyro_z  = (float)raw[5] / 131.0f * (M_PI / 180.0f);
    
    /* Complementary filter for orientation fusion */
    static float yaw = 0, pitch = 0, roll = 0;
    float dt = 1.0f / 200.0f; /* IMU runs at 200Hz */
    float alpha = 0.98f;       /* Gyro trust factor */
    
    /* Gyro integration */
    yaw   += data->gyro_z * dt;
    pitch += data->gyro_x * dt;
    roll  += data->gyro_y * dt;
    
    /* Accelerometer correction (gravity reference) */
    float accel_pitch = atan2f(data->accel_x, 
                                sqrtf(data->accel_y * data->accel_y + 
                                      data->accel_z * data->accel_z));
    float accel_roll  = atan2f(data->accel_y, data->accel_z);
    
    pitch = alpha * pitch + (1.0f - alpha) * accel_pitch;
    roll  = alpha * roll  + (1.0f - alpha) * accel_roll;
    /* Yaw cannot be corrected by accelerometer (needs magnetometer) */
    
    data->yaw = yaw;
    data->pitch = pitch;
    data->roll = roll;
    data->timestamp_us = ss_get_time_us();
}

/* ═══════════════════════════════════════════════════════════
 * PIPELINE INITIALIZATION
 * ═══════════════════════════════════════════════════════════ */

int ss_pipeline_init(ss_pipeline_t* p) {
    memset(p, 0, sizeof(ss_pipeline_t));
    
    /* ── Initialize all hardware drivers ── */
    
    /* 1. LiDAR sensors (SPI) */
    if (lidar_init() != 0) {
        ss_log("ERROR: LiDAR init failed");
        return -1;
    }
    ss_log("LiDAR: 2× dToF sensors initialized, 20fps, 15m range");
    
    /* 2. MEMS ultrasonic transducers */
    if (mems_ultrasonic_init() != 0) {
        ss_log("ERROR: MEMS ultrasonic init failed");
        return -2;
    }
    ss_log("MEMS: 40kHz TX/RX pair initialized, FM chirp ready");
    
    /* 3. MEMS microphones (click detection) */
    if (mems_microphone_init() != 0) {
        ss_log("ERROR: Microphone init failed");
        return -3;
    }
    ss_log("MIC: PDM microphones initialized, click detection armed");
    
    /* 4. HRTF database */
    rir_init_hrtf();
    ss_log("HRTF: 72-direction table loaded (5° resolution)");
    
    /* 5. Audio output (I2S to bone conduction) */
    audio_output_init();
    ss_log("AUDIO: I2S output to bone conduction drivers, 48kHz stereo");
    
    /* 6. BLE stack (haptic wristband link) */
    ss_ble_init();
    ss_log("BLE: nRF5340 stack initialized, wristband pairing...");
    
    /* ── Initialize training state ── */
    p->training.current_week = 1;
    p->training.augmentation = 1.0f;
    p->training.level = DIKW_DATA;
    p->training.click_accuracy = 0.0f;
    p->training.total_clicks = 0;
    scaffold_start_session(&p->training);
    
    /* ── System ready ── */
    p->is_running = true;
    p->click_pending = false;
    p->temperature_c = 20.0f;
    p->humidity_pct = 50.0f;
    
    ss_log("═══════════════════════════════════════");
    ss_log("  Chōra Pipeline READY");
    ss_log("  Pipeline budget: 8.0ms");
    ss_log("  Training week: %d, Aug: %.0f%%", 
           p->training.current_week,
           p->training.augmentation * 100.0f);
    ss_log("═══════════════════════════════════════");
    
    return 0;
}

/* ═══════════════════════════════════════════════════════════
 * MAIN PIPELINE EXECUTION
 * The complete 8ms signal chain from click to output
 * ═══════════════════════════════════════════════════════════ */

/**
 * Execute the full pipeline for one click event.
 * 
 * This is the core function — called when a click is detected.
 * It must complete in <8ms to stay below auditory fusion threshold.
 * 
 * Signal flow:
 *   User clicks → Mic detects onset → LiDAR captures geometry →
 *   Ray cast through point cloud → Material classification →
 *   RIR synthesis (predicted echo) → HRTF spatialization →
 *   Bone conduction output (augmented echo) + Haptic grid update
 */
int ss_pipeline_run(ss_pipeline_t* p) {
    p->pipeline_start_us = ss_get_time_us();
    
    /* ════════════════════════════════════════════════════
     * STAGE 1: CLICK DETECTION (budget: 0.5ms)
     * Already completed by interrupt — click_pending is set
     * Read IMU for head orientation at click time
     * ════════════════════════════════════════════════════ */
    
    imu_read(&p->imu);
    
    /* ════════════════════════════════════════════════════
     * STAGE 2: LiDAR CAPTURE (budget: 2.0ms)
     * Capture 3D point cloud from both dToF sensors
     * Voxelize into spatial occupancy grid
     * ════════════════════════════════════════════════════ */
    
    int lidar_result = lidar_capture_frame(&p->point_cloud);
    if (lidar_result == 0) {
        lidar_voxelize(&p->point_cloud, &p->voxel_grid);
    } else {
        /* LiDAR failed — use previous frame (graceful degradation) */
        ss_log("WARN: LiDAR capture failed, using cached geometry");
    }
    
    /* ════════════════════════════════════════════════════
     * STAGE 3: RAY CASTING (budget: 1.0ms)
     * Cast acoustic rays through voxel grid
     * Compute predicted echo returns for each surface hit
     * ════════════════════════════════════════════════════ */
    
    int echo_count = ag_ray_cast(
        &p->voxel_grid,
        0.0f, 0.0f, 0.0f,           /* Origin (device position) */
        p->imu.yaw, p->imu.pitch,   /* Head orientation */
        &p->echo_field
    );
    
    /* ════════════════════════════════════════════════════
     * STAGE 4: MATERIAL CLASSIFICATION (budget: 1.0ms)
     * Classify surface materials from echo spectral signatures
     * Apply environmental corrections (temperature, humidity)
     * ════════════════════════════════════════════════════ */
    
    /* Also run MEMS ultrasonic for independent echo measurement */
    float us_dist_l, us_dist_r, us_amp_l, us_amp_r;
    mems_echo_measure(&us_dist_l, &us_dist_r, &us_amp_l, &us_amp_r);
    
    /* Cross-validate LiDAR distances with ultrasonic measurements */
    /* (Sensor fusion — like autonomous vehicle multi-modal validation) */
    
    /* Apply environmental channel model (Equation 4) */
    ag_apply_environmental_correction(
        &p->echo_field, p->temperature_c, p->humidity_pct
    );
    
    /* ════════════════════════════════════════════════════
     * STAGE 5: RIR SYNTHESIS (budget: 1.5ms)
     * Predict Room Impulse Response from echo field
     * This is what the echo SHOULD sound like given the geometry
     * ════════════════════════════════════════════════════ */
    
    float rir[512];
    int rir_length = rir_synthesize(&p->echo_field, rir);
    
    /* ════════════════════════════════════════════════════
     * STAGE 6: HRTF RENDER (budget: 1.0ms)
     * Spatialize echo returns into binaural bone conduction signal
     * Each echo placed at its 3D direction using HRTF filters
     * ════════════════════════════════════════════════════ */
    
    rir_render_binaural(
        &p->echo_field,
        &p->audio,
        p->training.augmentation  /* Training scaffold scaling */
    );
    
    /* Add three-band grammar signal (geometry/crowd/material tones) */
    rir_synthesize_grammar(
        &p->echo_field,
        &p->audio,
        p->training.augmentation
    );
    
    /* ════════════════════════════════════════════════════
     * STAGE 7: BONE CONDUCTION OUTPUT (budget: 0.5ms)
     * Write binaural audio to I2S output buffer
     * DMA handles continuous playback
     * ════════════════════════════════════════════════════ */
    
    audio_output_write(&p->audio);
    
    /* ════════════════════════════════════════════════════
     * STAGE 8: HAPTIC GRID MAP (budget: 0.5ms)
     * Convert echo field → 3×3 wristband vibrotactile pattern
     * Transmit via BLE to wristband co-processor
     * ════════════════════════════════════════════════════ */
    
    haptic_map_echo_field(
        &p->echo_field,
        &p->haptic,
        p->training.augmentation
    );
    
    haptic_send_to_wristband(&p->haptic);
    
    /* ════════════════════════════════════════════════════
     * POST-PIPELINE: Training scaffold update
     * ════════════════════════════════════════════════════ */
    
    scaffold_update(&p->training, &p->echo_field, &p->imu);
    
    /* ── Measure total pipeline latency ── */
    p->pipeline_end_us = ss_get_time_us();
    p->pipeline_latency_ms = (float)(p->pipeline_end_us - p->pipeline_start_us) / 1000.0f;
    
    /* Verify timing budget */
    if (p->pipeline_latency_ms > PIPELINE_BUDGET_MS) {
        ss_log("WARN: Pipeline exceeded budget: %.2fms > %.1fms",
               p->pipeline_latency_ms, PIPELINE_BUDGET_MS);
    }
    
    p->click_pending = false;
    return 0;
}

/* ═══════════════════════════════════════════════════════════
 * MAIN APPLICATION LOOP
 * Runs on Zephyr RTOS — real-time thread priority
 * ═══════════════════════════════════════════════════════════ */

/**
 * Microphone interrupt callback — called when PDM block is ready.
 * Checks for click onset and sets click_pending flag.
 */
void mic_pdm_callback(const float* samples, int count) {
    ss_click_event_t click;
    int detected = mems_detect_click(samples, count, &click);
    
    if (detected == 1) {
        pipeline.last_click = click;
        pipeline.click_pending = true;
    }
}

/**
 * Main application entry point.
 * Initializes all subsystems and enters the real-time loop.
 */
int main(void) {
    ss_log("Chōra v1.0 — Echolocation Augmentation System");
    ss_log("Platform: Alif Ensemble E7 (ARM Cortex-M55 + Ethos-U55)");
    ss_log("Initializing pipeline...\n");
    
    /* Initialize the complete pipeline */
    int result = ss_pipeline_init(&pipeline);
    if (result != 0) {
        ss_log("FATAL: Pipeline init failed with error %d", result);
        return result;
    }
    
    /* Register microphone callback for click detection */
    ss_pdm_set_callback(mic_pdm_callback, MIC_BLOCK_SIZE);
    
    /* ── Main real-time loop ── */
    ss_log("Entering main loop. Waiting for clicks...\n");
    
    while (pipeline.is_running) {
        
        if (pipeline.click_pending) {
            /* ═══ CLICK DETECTED — RUN FULL PIPELINE ═══ */
            ss_pipeline_run(&pipeline);
            
            /* Log pipeline performance */
            if (pipeline.training.session_clicks % 50 == 0) {
                ss_log("[Click #%d] Latency: %.2fms | Aug: %.0f%% | "
                       "Accuracy: %.1f%% | DIKW: %d | V1: %.2f",
                       pipeline.training.total_clicks,
                       pipeline.pipeline_latency_ms,
                       pipeline.training.augmentation * 100.0f,
                       pipeline.training.click_accuracy * 100.0f,
                       pipeline.training.level,
                       pipeline.training.v1_activation_est);
            }
        }
        
        /* Background tasks (low priority) */
        /* - Battery monitoring */
        /* - Temperature/humidity sensor read (1Hz) */
        /* - BLE connection maintenance */
        /* - Fleet learning data upload */
        
        /* Yield to RTOS scheduler */
        ss_thread_yield();
    }
    
    /* Shutdown */
    scaffold_end_session(&pipeline.training);
    lidar_set_power_mode(0);
    ss_log("Chōra shutdown complete.");
    
    return 0;
}
