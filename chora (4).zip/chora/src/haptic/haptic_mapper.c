/**
 * Chōra — Haptic Grid Mapper
 * 
 * Converts the echo field spatial data into a 3×3 vibrotactile
 * pattern on the wristband. This is the "felt" spatial channel.
 * 
 * Grid layout (user's perspective, palm up):
 *   [Far-L]  [Far-C]  [Far-R]     Row 0: objects at 5–15m
 *   [Mid-L]  [Mid-C]  [Mid-R]     Row 1: objects at 1.5–5m  
 *   [Near-L] [Near-C] [Near-R]    Row 2: objects at 0–1.5m
 * 
 * Each cell encodes three parameters:
 *   - Intensity (0–1): confidence of detection
 *   - Frequency (Hz): vibration speed (material encoding)
 *   - Pattern: temporal pulse shape (moving vs static)
 * 
 * Communicates via BLE to wristband co-processor (nRF52832).
 * Link latency: 4ms. Haptic update rate: 60Hz.
 */

#include "core/pipeline.h"
#include "haptic/haptic_mapper.h"
#include <math.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════
 * SPATIAL MAPPING PARAMETERS
 * ═══════════════════════════════════════════════════════════ */

/* Distance thresholds for row mapping */
#define RANGE_NEAR_M     1.5f   /* 0–1.5m → row 2 (bottom) */
#define RANGE_MID_M      5.0f   /* 1.5–5m → row 1 (middle) */
#define RANGE_FAR_M      15.0f  /* 5–15m → row 0 (top) */

/* Azimuth thresholds for column mapping */
#define AZ_LEFT_RAD      (-0.5236f)  /* < -30° → column 0 (left) */
#define AZ_RIGHT_RAD     (0.5236f)   /* > +30° → column 2 (right) */

/* Haptic actuator parameters (TDK PowerHap 1204H) */
#define HAPTIC_MIN_FREQ_HZ    50     /* Minimum vibration frequency */
#define HAPTIC_MAX_FREQ_HZ    300    /* Maximum vibration frequency */
#define HAPTIC_RESONANCE_HZ   250    /* Resonant frequency (strongest) */

/* Material → vibration texture mapping */
typedef struct {
    float frequency_hz;   /* Vibration frequency */
    uint8_t pattern;      /* 0=continuous, 1=pulse, 2=ramp, 3=burst */
    float duty_cycle;     /* For pulsed patterns (0.0–1.0) */
} haptic_texture_t;

static const haptic_texture_t MATERIAL_HAPTIC[MAT_COUNT] = {
    /* UNKNOWN  */ { 150.0f, 0, 1.0f },
    /* CONCRETE */ { 80.0f,  0, 1.0f },   /* Continuous low rumble */
    /* STONE    */ { 70.0f,  0, 1.0f },   /* Deep steady vibration */
    /* WOOD     */ { 180.0f, 0, 1.0f },   /* Warm continuous hum */
    /* GLASS    */ { 280.0f, 2, 0.8f },   /* High-freq ramp (shimmer) */
    /* METAL    */ { 250.0f, 3, 0.5f },   /* Sharp bursts (ring) */
    /* FOLIAGE  */ { 120.0f, 1, 0.3f },   /* Soft intermittent pulse */
    /* WATER    */ { 200.0f, 1, 0.6f },   /* Medium pulse (flow) */
    /* FABRIC   */ { 100.0f, 0, 0.5f },   /* Very soft continuous */
    /* HUMAN    */ { 160.0f, 1, 0.4f },   /* Pulsed (heartbeat-like) */
};

/* ═══════════════════════════════════════════════════════════
 * SPATIAL BINNING — Echo returns → Grid cells
 * ═══════════════════════════════════════════════════════════ */

/**
 * Map an azimuth angle to grid column index (0=left, 1=center, 2=right).
 */
static int azimuth_to_column(float azimuth_rad) {
    if (azimuth_rad < AZ_LEFT_RAD) return 0;       /* Left */
    if (azimuth_rad > AZ_RIGHT_RAD) return 2;       /* Right */
    return 1;                                         /* Center */
}

/**
 * Map a distance to grid row index (0=far, 1=mid, 2=near).
 */
static int distance_to_row(float distance_m) {
    if (distance_m < RANGE_NEAR_M) return 2;         /* Near */
    if (distance_m < RANGE_MID_M)  return 1;         /* Mid */
    return 0;                                          /* Far */
}

/**
 * Convert echo field into haptic grid frame.
 * 
 * Algorithm:
 *   1. For each echo return, determine which grid cell it falls in
 *   2. Accumulate intensity (weighted by amplitude and proximity)
 *   3. Select dominant material for frequency/texture encoding
 *   4. Apply augmentation scaling (training scaffold)
 * 
 * @param field          Echo field from acoustic grammar
 * @param haptic         Output haptic frame
 * @param augmentation   Training scaffold level (0.0–1.0)
 */
void haptic_map_echo_field(
    const ss_echo_field_t* field,
    ss_haptic_frame_t* haptic,
    float augmentation
) {
    /* Clear grid */
    memset(haptic->cells, 0, sizeof(haptic->cells));
    haptic->timestamp_us = ss_get_time_us();
    haptic->augmentation_level = augmentation;
    
    /* Track dominant material per cell */
    float cell_max_amp[HAPTIC_ROWS][HAPTIC_COLS];
    ss_material_t cell_material[HAPTIC_ROWS][HAPTIC_COLS];
    memset(cell_max_amp, 0, sizeof(cell_max_amp));
    for (int r = 0; r < HAPTIC_ROWS; r++)
        for (int c = 0; c < HAPTIC_COLS; c++)
            cell_material[r][c] = MAT_UNKNOWN;
    
    /* ── Bin echo returns into grid cells ── */
    for (int i = 0; i < field->count; i++) {
        const ss_echo_return_t* echo = &field->returns[i];
        
        int col = azimuth_to_column(echo->azimuth_rad);
        int row = distance_to_row(echo->distance_m);
        
        /* Compute intensity: inverse distance, weighted by amplitude */
        float proximity_weight;
        if (echo->distance_m < RANGE_NEAR_M) {
            proximity_weight = 1.0f; /* Full intensity for close objects */
        } else {
            proximity_weight = RANGE_NEAR_M / echo->distance_m;
        }
        
        float intensity = echo->amplitude * proximity_weight;
        
        /* Accumulate (max operation — strongest detection wins) */
        if (intensity > haptic->cells[row][col].intensity) {
            haptic->cells[row][col].intensity = intensity;
        }
        
        /* Track dominant material (highest amplitude wins) */
        if (echo->amplitude > cell_max_amp[row][col]) {
            cell_max_amp[row][col] = echo->amplitude;
            cell_material[row][col] = echo->material;
        }
    }
    
    /* ── Apply material textures and augmentation scaling ── */
    for (int r = 0; r < HAPTIC_ROWS; r++) {
        for (int c = 0; c < HAPTIC_COLS; c++) {
            ss_haptic_cell_t* cell = &haptic->cells[r][c];
            
            /* Apply augmentation scaling */
            cell->intensity *= augmentation;
            
            /* Clamp to [0, 1] */
            cell->intensity = fminf(1.0f, fmaxf(0.0f, cell->intensity));
            
            /* Apply material-specific vibration texture */
            ss_material_t mat = cell_material[r][c];
            const haptic_texture_t* tex = &MATERIAL_HAPTIC[mat];
            
            cell->frequency = tex->frequency_hz;
            cell->pattern = tex->pattern;
            
            /* Scale frequency by intensity (louder = faster vibration) */
            cell->frequency *= (0.7f + 0.3f * cell->intensity);
            
            /* Clamp frequency to actuator range */
            cell->frequency = fminf(HAPTIC_MAX_FREQ_HZ, 
                              fmaxf(HAPTIC_MIN_FREQ_HZ, cell->frequency));
        }
    }
}

/* ═══════════════════════════════════════════════════════════
 * BLE TRANSMISSION — Send haptic frame to wristband
 * ═══════════════════════════════════════════════════════════ */

/** BLE characteristic for haptic data (9 cells × 3 bytes each = 27 bytes) */
#define HAPTIC_BLE_CHAR_UUID    0xFF01
#define HAPTIC_PACKET_SIZE      27

/**
 * Encode haptic frame into compact BLE packet.
 * 
 * Format per cell (3 bytes):
 *   Byte 0: intensity (0–255, mapped from 0.0–1.0)
 *   Byte 1: frequency (0–255, mapped from 50–300 Hz)
 *   Byte 2: pattern (0–3) | duty_cycle (4 bits)
 */
int haptic_encode_ble_packet(const ss_haptic_frame_t* frame, 
                              uint8_t* packet) {
    int pos = 0;
    
    for (int r = 0; r < HAPTIC_ROWS; r++) {
        for (int c = 0; c < HAPTIC_COLS; c++) {
            const ss_haptic_cell_t* cell = &frame->cells[r][c];
            
            /* Intensity: float → uint8 */
            packet[pos++] = (uint8_t)(cell->intensity * 255.0f);
            
            /* Frequency: map 50–300Hz range to uint8 */
            float f_norm = (cell->frequency - HAPTIC_MIN_FREQ_HZ) / 
                           (float)(HAPTIC_MAX_FREQ_HZ - HAPTIC_MIN_FREQ_HZ);
            packet[pos++] = (uint8_t)(fminf(1.0f, fmaxf(0.0f, f_norm)) * 255.0f);
            
            /* Pattern + duty cycle packed into 1 byte */
            uint8_t pat = (cell->pattern & 0x03) << 4;
            /* Duty cycle from material texture table */
            ss_material_t mat = MAT_UNKNOWN; /* Would look up from context */
            pat |= (uint8_t)(MATERIAL_HAPTIC[mat].duty_cycle * 15.0f) & 0x0F;
            packet[pos++] = pat;
        }
    }
    
    return pos; /* Should be 27 bytes */
}

/**
 * Send haptic frame to wristband via BLE.
 * Uses BLE 5.3 connection with 4ms interval for low latency.
 */
int haptic_send_to_wristband(const ss_haptic_frame_t* frame) {
    uint8_t packet[HAPTIC_PACKET_SIZE];
    int len = haptic_encode_ble_packet(frame, packet);
    
    /* Send via BLE GATT notification (non-blocking) */
    return ss_ble_notify(HAPTIC_BLE_CHAR_UUID, packet, len);
}

/* ═══════════════════════════════════════════════════════════
 * WRISTBAND FIRMWARE (nRF52832 co-processor)
 * Receives BLE packets and drives 9 haptic actuators
 * ═══════════════════════════════════════════════════════════ */

/**
 * Wristband actuator driver — runs on nRF52832.
 * 
 * Each of the 9 TDK PowerHap actuators is driven by a PWM channel.
 * The PWM frequency sets the vibration frequency (50–300Hz).
 * The PWM duty cycle sets the vibration intensity (0–100%).
 * The temporal pattern modulates the PWM on/off for texture encoding.
 * 
 * Pin mapping:
 *   Actuator 0 (Far-L):  PWM0 Channel 0
 *   Actuator 1 (Far-C):  PWM0 Channel 1
 *   Actuator 2 (Far-R):  PWM0 Channel 2
 *   Actuator 3 (Mid-L):  PWM1 Channel 0
 *   Actuator 4 (Mid-C):  PWM1 Channel 1
 *   Actuator 5 (Mid-R):  PWM1 Channel 2
 *   Actuator 6 (Near-L): PWM2 Channel 0
 *   Actuator 7 (Near-C): PWM2 Channel 1
 *   Actuator 8 (Near-R): PWM2 Channel 2
 */
void haptic_actuator_update(int actuator_id, float intensity,
                             float freq_hz, uint8_t pattern) {
    /* Compute PWM parameters */
    uint32_t pwm_period_us = (uint32_t)(1e6f / freq_hz);
    uint32_t pwm_duty_us = (uint32_t)(pwm_period_us * intensity);
    
    /* Select PWM module and channel */
    int pwm_module = actuator_id / 3;
    int pwm_channel = actuator_id % 3;
    
    /* Apply pattern modulation */
    switch (pattern) {
        case 0: /* Continuous — no modulation */
            break;
        case 1: /* Pulse — 4Hz on/off modulation */
            /* Implemented in timer ISR */
            break;
        case 2: /* Ramp — intensity fades in over 100ms */
            break;
        case 3: /* Burst — 3 rapid pulses then pause */
            break;
    }
    
    /* Set PWM output */
    ss_pwm_set(pwm_module, pwm_channel, pwm_period_us, pwm_duty_us);
}
