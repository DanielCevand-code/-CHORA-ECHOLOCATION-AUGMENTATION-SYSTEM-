/**
 * Chōra — Training Scaffold Engine (DIKW Progression)
 * 
 * Manages the adaptive training process that teaches the user's
 * visual cortex to decode acoustic echoes as spatial geometry.
 * 
 * The training follows the DIKW pyramid:
 *   DATA (Weeks 1–2):        100% augmentation, raw signal exposure
 *   INFORMATION (Weeks 3–5): 80→50% augmentation, pattern recognition
 *   KNOWLEDGE (Weeks 6–8):   50→25% augmentation, cortical internalization
 *   WISDOM (Weeks 9–10):     25→0% augmentation, autonomous echolocation
 * 
 * The key principle: the device teaches, then fades.
 * After training, the spatial map lives in the cortex permanently.
 * 
 * Like an AI training pipeline: collect → train → validate → deploy.
 * But the "model" is the human brain, and deployment is permanent.
 */

#include "core/pipeline.h"
#include "training/scaffold.h"
#include <math.h>

/* ═══════════════════════════════════════════════════════════
 * TRAINING SCHEDULE
 * ═══════════════════════════════════════════════════════════ */

typedef struct {
    uint8_t          week_start;
    uint8_t          week_end;
    ss_dikw_level_t  level;
    float            aug_start;      /* Augmentation at week start */
    float            aug_end;        /* Augmentation at week end */
    float            complexity;     /* Environment complexity scaling */
    const char*      description;
} training_phase_t;

static const training_phase_t TRAINING_SCHEDULE[] = {
    { 1, 2,  DIKW_DATA,        1.00f, 0.90f, 0.3f,
      "Full augmentation. User learns click technique. "
      "Controlled environment (training room, hallway). "
      "Brain receives structured signal it cannot generate alone." },
    
    { 3, 4,  DIKW_INFORMATION, 0.80f, 0.60f, 0.5f,
      "Augmented echo amplitude reduced. User begins relying "
      "on natural echoes. Haptic grid complexity increases. "
      "V1 cortex begins forming echo→geometry mappings." },
    
    { 5, 6,  DIKW_INFORMATION, 0.50f, 0.35f, 0.7f,
      "Half-strength augmentation. User navigates familiar spaces "
      "with natural clicks alone. Novel spaces still need support. "
      "Like reducing teacher forcing in sequence-to-sequence models." },
    
    { 7, 8,  DIKW_KNOWLEDGE,   0.25f, 0.15f, 0.9f,
      "Light augmentation. Device only activates for complex geometry "
      "(intersections, open plazas). User handles corridors and rooms "
      "independently. Cortical model is generalizing." },
    
    { 9, 10, DIKW_WISDOM,      0.10f, 0.00f, 1.0f,
      "Near-zero augmentation. Device monitors but rarely intervenes. "
      "Final assessment: can user navigate novel space with clicks alone? "
      "The 'model' is deployed — permanently, in wetware." },
};

#define NUM_PHASES (sizeof(TRAINING_SCHEDULE) / sizeof(TRAINING_SCHEDULE[0]))

/* ═══════════════════════════════════════════════════════════
 * PERFORMANCE METRICS — Tracking user's cortical learning
 * ═══════════════════════════════════════════════════════════ */

#define METRIC_HISTORY_LEN  100
#define SESSION_MAX_CLICKS  500

typedef struct {
    /* Click accuracy: can user point to echo source direction? */
    float direction_errors[METRIC_HISTORY_LEN];  /* Angular error (rad) */
    int   direction_count;
    
    /* Distance discrimination: can user judge relative distance? */
    float distance_errors[METRIC_HISTORY_LEN];   /* Distance error (m) */
    int   distance_count;
    
    /* Material identification: can user classify surface type? */
    uint16_t material_correct;
    uint16_t material_total;
    
    /* Navigation efficiency: path length vs optimal */
    float path_efficiency[METRIC_HISTORY_LEN];   /* Ratio (0–1) */
    int   path_count;
    
    /* Temporal tracking */
    uint32_t session_start_time;
    uint32_t total_training_time_s;
} training_metrics_t;

static training_metrics_t metrics = {0};

/* ═══════════════════════════════════════════════════════════
 * AUGMENTATION LEVEL COMPUTATION
 * ═══════════════════════════════════════════════════════════ */

/**
 * Compute current augmentation level based on week and session progress.
 * 
 * The augmentation follows a sigmoid-like curve within each phase,
 * with sharp drops at phase transitions and gradual fades within phases.
 * 
 * Adaptive: if user's accuracy drops below threshold, augmentation
 * temporarily increases (scaffolding principle — don't let them fail).
 */
float scaffold_compute_augmentation(const ss_training_state_t* state) {
    uint8_t week = state->current_week;
    
    /* Find current phase */
    const training_phase_t* phase = &TRAINING_SCHEDULE[0];
    for (int i = 0; i < (int)NUM_PHASES; i++) {
        if (week >= TRAINING_SCHEDULE[i].week_start && 
            week <= TRAINING_SCHEDULE[i].week_end) {
            phase = &TRAINING_SCHEDULE[i];
            break;
        }
    }
    
    /* Linear interpolation within phase */
    float phase_progress = (float)(week - phase->week_start) / 
                           (float)(phase->week_end - phase->week_start + 1);
    float base_augmentation = phase->aug_start + 
                              (phase->aug_end - phase->aug_start) * phase_progress;
    
    /* ── Adaptive adjustment ── */
    /* If user is struggling (accuracy < 60%), boost augmentation */
    float accuracy = state->click_accuracy;
    if (accuracy < 0.6f && base_augmentation < 0.5f) {
        /* Smoothly increase augmentation when accuracy drops */
        float boost = (0.6f - accuracy) * 0.5f;
        base_augmentation = fminf(base_augmentation + boost, 
                                   phase->aug_start);
    }
    
    /* If user is excelling (accuracy > 90%), allow faster fade */
    if (accuracy > 0.9f && base_augmentation > 0.1f) {
        float speedup = (accuracy - 0.9f) * 0.3f;
        base_augmentation = fmaxf(base_augmentation - speedup, 
                                   phase->aug_end);
    }
    
    return fminf(1.0f, fmaxf(0.0f, base_augmentation));
}

/* ═══════════════════════════════════════════════════════════
 * CLICK ACCURACY MEASUREMENT
 * ═══════════════════════════════════════════════════════════ */

/**
 * After the user clicks and the device processes the echo field,
 * compare the user's reported spatial awareness with the ground
 * truth from LiDAR. This is the "loss function" for training.
 * 
 * The user's "report" is implicit: their navigation decision
 * (which direction they turn/walk) reveals what they perceived.
 * The IMU tracks head movement after each click.
 * 
 * If they turn toward the detected obstacle (LiDAR ground truth),
 * they perceived it correctly. If they don't, they missed it.
 */
void scaffold_update_accuracy(
    ss_training_state_t* state,
    const ss_echo_field_t* echo_field,
    const ss_imu_data_t* imu_after_click
) {
    if (echo_field->count == 0) return;
    
    /* Find nearest echo return (most salient object) */
    float min_dist = 999.0f;
    float nearest_azimuth = 0.0f;
    for (int i = 0; i < echo_field->count; i++) {
        if (echo_field->returns[i].distance_m < min_dist) {
            min_dist = echo_field->returns[i].distance_m;
            nearest_azimuth = echo_field->returns[i].azimuth_rad;
        }
    }
    
    /* Compare with head movement direction after click */
    /* If object is < 3m and user turned toward it → correct perception */
    float head_turn = imu_after_click->yaw; /* Relative to click time */
    float angular_error = fabsf(head_turn - nearest_azimuth);
    
    /* Wrap to [0, π] */
    if (angular_error > M_PI) angular_error = 2.0f * M_PI - angular_error;
    
    /* Store in metrics history */
    int idx = metrics.direction_count % METRIC_HISTORY_LEN;
    metrics.direction_errors[idx] = angular_error;
    metrics.direction_count++;
    
    /* Update running accuracy (fraction with error < 30°) */
    int correct = 0;
    int total = (metrics.direction_count < METRIC_HISTORY_LEN) ? 
                metrics.direction_count : METRIC_HISTORY_LEN;
    for (int i = 0; i < total; i++) {
        if (metrics.direction_errors[i] < 0.5236f) { /* <30° */
            correct++;
        }
    }
    state->click_accuracy = (float)correct / (float)total;
    
    /* Update DIKW level */
    state->total_clicks++;
    state->session_clicks++;
}

/* ═══════════════════════════════════════════════════════════
 * DIKW LEVEL ASSESSMENT
 * ═══════════════════════════════════════════════════════════ */

/**
 * Assess current DIKW level based on performance metrics.
 * This determines the training phase and augmentation schedule.
 */
ss_dikw_level_t scaffold_assess_dikw_level(const ss_training_state_t* state) {
    /* 
     * DATA: User clicks but cannot discriminate directions
     *   → accuracy < 40%, or week 1–2
     * 
     * INFORMATION: User recognizes patterns, some discrimination
     *   → accuracy 40–70%, responding to echo structure
     * 
     * KNOWLEDGE: User navigates familiar spaces independently
     *   → accuracy 70–85%, generalizes to similar environments
     * 
     * WISDOM: User navigates novel spaces with natural clicks
     *   → accuracy > 85% without augmentation
     */
    
    float acc = state->click_accuracy;
    float aug = state->augmentation;
    
    if (acc < 0.4f || state->current_week <= 2) {
        return DIKW_DATA;
    }
    
    if (acc < 0.7f || state->current_week <= 5) {
        return DIKW_INFORMATION;
    }
    
    /* Knowledge requires demonstrating ability at reduced augmentation */
    if (aug > 0.2f || acc < 0.85f) {
        return DIKW_KNOWLEDGE;
    }
    
    /* Wisdom: high accuracy at near-zero augmentation */
    if (acc >= 0.85f && aug <= 0.1f) {
        return DIKW_WISDOM;
    }
    
    return DIKW_KNOWLEDGE;
}

/* ═══════════════════════════════════════════════════════════
 * SESSION MANAGEMENT
 * ═══════════════════════════════════════════════════════════ */

/**
 * Initialize a new training session.
 * Called when the device is powered on or user starts a session.
 */
void scaffold_start_session(ss_training_state_t* state) {
    state->session_clicks = 0;
    metrics.session_start_time = ss_get_time_us();
    
    /* Compute augmentation for this session */
    state->augmentation = scaffold_compute_augmentation(state);
    state->level = scaffold_assess_dikw_level(state);
}

/**
 * End training session. Save metrics for longitudinal tracking.
 */
void scaffold_end_session(ss_training_state_t* state) {
    uint32_t duration = ss_get_time_us() - metrics.session_start_time;
    metrics.total_training_time_s += duration / 1000000;
    
    /* Log session summary for fleet learning */
    scaffold_log_session(state, &metrics);
}

/**
 * Per-click update — called after every pipeline execution.
 * Updates augmentation level and checks for DIKW transitions.
 */
void scaffold_update(ss_training_state_t* state,
                      const ss_echo_field_t* field,
                      const ss_imu_data_t* imu) {
    /* Update accuracy from this click's result */
    scaffold_update_accuracy(state, field, imu);
    
    /* Recompute augmentation (may adapt based on performance) */
    state->augmentation = scaffold_compute_augmentation(state);
    
    /* Check for DIKW level transition */
    ss_dikw_level_t new_level = scaffold_assess_dikw_level(state);
    if (new_level != state->level) {
        state->level = new_level;
        /* Signal transition (haptic feedback, audio cue) */
        scaffold_notify_transition(state);
    }
    
    /* Estimate V1 activation (rough proxy from accuracy curve) */
    /* Based on Norman, Hartley & Thaler (2024) fMRI data */
    state->v1_activation_est = fminf(1.0f, 
        state->click_accuracy * 0.8f + 
        (float)state->total_clicks / 10000.0f * 0.2f
    );
}

/* ═══════════════════════════════════════════════════════════
 * FLEET LEARNING — Session data for collective improvement
 * ═══════════════════════════════════════════════════════════ */

/**
 * Log anonymized session metrics for fleet learning.
 * Sent via BLE → phone → cloud (federated, privacy-preserving).
 * 
 * The data that flows back:
 *   - Accuracy curves per DIKW level (averaged across all users)
 *   - Common failure patterns (which geometries are hardest?)
 *   - Optimal augmentation schedules (data-driven improvement)
 * 
 * This is how users sharpen the system for future users.
 */
void scaffold_log_session(const ss_training_state_t* state,
                           const training_metrics_t* m) {
    /* Anonymized session record */
    typedef struct {
        uint8_t  dikw_level;
        uint8_t  week;
        float    accuracy;
        float    augmentation;
        uint16_t clicks;
        uint16_t duration_minutes;
        float    v1_estimate;
    } session_record_t;
    
    session_record_t record = {
        .dikw_level = (uint8_t)state->level,
        .week = state->current_week,
        .accuracy = state->click_accuracy,
        .augmentation = state->augmentation,
        .clicks = (uint16_t)state->session_clicks,
        .duration_minutes = (uint16_t)(m->total_training_time_s / 60),
        .v1_estimate = state->v1_activation_est,
    };
    
    /* Send to BLE uplink (phone companion app relays to cloud) */
    ss_ble_send_fleet_data(&record, sizeof(record));
}
