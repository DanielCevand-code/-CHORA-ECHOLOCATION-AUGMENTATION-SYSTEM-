/**
 * Chōra — Acoustic Grammar DSP Engine
 * 
 * Implements the four core equations that form the computational
 * grammar of spatial echolocation:
 * 
 *   Equation 1: d = c · Δτ / 2         (Echo Distance — ToA ranging)
 *   Equation 2: α(f) = 1.17e-5 · f²    (Atmospheric Attenuation)
 *   Equation 3: Hᵢ = |Σ Aⱼ·e^(iφⱼ)|   (Harmonic Interference Field)
 *   Equation 4: α(f,H) = k·f²·e^(-βH)  (Environmental Channel Model)
 * 
 * This module takes the point cloud from LiDAR + echo data from MEMS
 * and produces a structured 3-band acoustic output:
 *   - Low band  (125–500 Hz):  Room geometry / volume
 *   - Mid band  (500–2000 Hz): Crowd density / moving bodies  
 *   - High band (2000–8000 Hz): Surface material / texture
 * 
 * This is the brain of the system — the telecoms engineering core.
 */

#include "core/pipeline.h"
#include "dsp/acoustic_grammar.h"
#include <math.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════
 * MATERIAL ACOUSTIC PROPERTIES TABLE
 * Absorption coefficients and frequency response per material
 * ═══════════════════════════════════════════════════════════ */

static const ss_material_props_t MATERIAL_TABLE[MAT_COUNT] = {
    /* MAT_UNKNOWN  */ { 0.10f,  200, 4000, 0.20f, "unknown"  },
    /* MAT_CONCRETE */ { 0.02f,  125,  800, 0.05f, "concrete" },
    /* MAT_STONE    */ { 0.03f,  100,  600, 0.08f, "stone"    },
    /* MAT_WOOD     */ { 0.10f,  400, 2000, 0.15f, "wood"     },
    /* MAT_GLASS    */ { 0.04f, 2000, 8000, 0.03f, "glass"    },
    /* MAT_METAL    */ { 0.02f, 3000, 8000, 0.02f, "metal"    },
    /* MAT_FOLIAGE  */ { 0.50f,  300, 3000, 0.60f, "foliage"  },
    /* MAT_WATER    */ { 0.01f, 1000, 8000, 0.10f, "water"    },
    /* MAT_FABRIC   */ { 0.40f,  200, 4000, 0.50f, "fabric"   },
    /* MAT_HUMAN    */ { 0.30f,  300, 2000, 0.40f, "human"    },
};

/* ═══════════════════════════════════════════════════════════
 * FFT — Minimal fixed-point FFT for embedded DSP
 * 256-point radix-2 DIT FFT for spectral analysis
 * ═══════════════════════════════════════════════════════════ */

#define FFT_SIZE 256

typedef struct {
    float real;
    float imag;
} complex_f32_t;

/** Bit-reversal permutation */
static void fft_bit_reverse(complex_f32_t* x, int n) {
    int j = 0;
    for (int i = 0; i < n - 1; i++) {
        if (i < j) {
            complex_f32_t temp = x[i];
            x[i] = x[j];
            x[j] = temp;
        }
        int k = n >> 1;
        while (k <= j) { j -= k; k >>= 1; }
        j += k;
    }
}

/** Radix-2 Decimation-in-Time FFT */
static void fft_compute(complex_f32_t* x, int n) {
    fft_bit_reverse(x, n);
    
    for (int stage = 1; stage < n; stage <<= 1) {
        float angle = -M_PI / (float)stage;
        complex_f32_t w_step = { cosf(angle), sinf(angle) };
        
        for (int group = 0; group < n; group += (stage << 1)) {
            complex_f32_t w = { 1.0f, 0.0f };
            for (int pair = 0; pair < stage; pair++) {
                int i = group + pair;
                int j = i + stage;
                
                complex_f32_t t = {
                    w.real * x[j].real - w.imag * x[j].imag,
                    w.real * x[j].imag + w.imag * x[j].real
                };
                
                x[j].real = x[i].real - t.real;
                x[j].imag = x[i].imag - t.imag;
                x[i].real = x[i].real + t.real;
                x[i].imag = x[i].imag + t.imag;
                
                float w_new_real = w.real * w_step.real - w.imag * w_step.imag;
                w.imag = w.real * w_step.imag + w.imag * w_step.real;
                w.real = w_new_real;
            }
        }
    }
}

/** Compute magnitude spectrum */
static void fft_magnitude(const complex_f32_t* x, float* mag, int n) {
    for (int i = 0; i < n / 2; i++) {
        mag[i] = sqrtf(x[i].real * x[i].real + x[i].imag * x[i].imag);
    }
}

/* ═══════════════════════════════════════════════════════════
 * EQUATION 1: ECHO DISTANCE (ToA Ranging)
 * d = c · Δτ / 2
 * ═══════════════════════════════════════════════════════════ */

/**
 * Compute distance from echo delay.
 * Identical mathematics to radar/sonar/UWB indoor positioning.
 * 
 * @param delay_s      Round-trip time of flight (seconds)
 * @param temperature  Ambient temperature for sound speed correction
 * @return             One-way distance in meters
 */
float ag_compute_distance(float delay_s, float temperature_c) {
    /* Temperature-corrected speed of sound */
    float c = 331.3f + 0.606f * temperature_c;
    
    /* Equation 1: d = c · Δτ / 2 */
    return c * delay_s / 2.0f;
}

/**
 * Process all echo returns from a click event and compute distances.
 * Fills the echo_field with calibrated distance measurements.
 */
void ag_process_echo_distances(ss_echo_field_t* field, float temperature_c) {
    float c = 331.3f + 0.606f * temperature_c;
    
    for (int i = 0; i < field->count; i++) {
        ss_echo_return_t* echo = &field->returns[i];
        
        /* d = c · Δτ / 2 */
        echo->distance_m = c * echo->delay_s / 2.0f;
        
        /* Clamp to sensor range */
        if (echo->distance_m > LIDAR_RANGE_M) {
            echo->distance_m = LIDAR_RANGE_M;
        }
    }
}

/* ═══════════════════════════════════════════════════════════
 * EQUATION 2: ATMOSPHERIC ATTENUATION
 * α(f) = 1.17 × 10⁻⁵ · f²
 * ═══════════════════════════════════════════════════════════ */

/**
 * Compute frequency-dependent atmospheric attenuation.
 * Structurally identical to Friis transmission equation in RF propagation.
 * Higher frequencies attenuate faster — this is why material textures
 * are encoded in the high band (>2kHz) and room geometry in the low band.
 * 
 * @param freq_hz   Signal frequency
 * @param distance  Propagation distance (meters)
 * @return          Attenuation factor (0.0–1.0, 1.0 = no loss)
 */
float ag_atmospheric_attenuation(float freq_hz, float distance_m) {
    /* Equation 2: α(f) = 1.17 × 10⁻⁵ · f² */
    float alpha = 1.17e-5f * freq_hz * freq_hz;
    
    /* Total attenuation over distance (dB) */
    float atten_db = alpha * distance_m;
    
    /* Convert to linear factor */
    return powf(10.0f, -atten_db / 20.0f);
}

/**
 * Apply atmospheric attenuation to the full echo spectrum.
 * Each echo return's amplitude is scaled by its frequency-distance product.
 */
void ag_apply_attenuation(ss_echo_field_t* field) {
    for (int i = 0; i < field->count; i++) {
        ss_echo_return_t* echo = &field->returns[i];
        
        /* Get material's dominant frequency band */
        const ss_material_props_t* mat = &MATERIAL_TABLE[echo->material];
        float center_freq = (mat->freq_band_low + mat->freq_band_high) / 2.0f;
        
        /* Apply Equation 2 */
        echo->attenuation = ag_atmospheric_attenuation(
            center_freq, echo->distance_m
        );
        
        /* Scale amplitude by attenuation + material absorption */
        echo->amplitude *= echo->attenuation * (1.0f - mat->absorption_coeff);
    }
}

/* ═══════════════════════════════════════════════════════════
 * EQUATION 3: HARMONIC INTERFERENCE FIELD
 * Hᵢ = |Σ Aⱼ · e^(iφⱼ)|
 * ═══════════════════════════════════════════════════════════ */

/**
 * Compute the harmonic interference field from multiple echo sources.
 * Same mathematics as MIMO antenna beamforming / phased array steering.
 * 
 * When multiple surfaces reflect the click, their echoes arrive at
 * different phases and interfere constructively or destructively.
 * This interference pattern encodes the 3D geometry of the space —
 * room size, corner angles, open vs. enclosed volumes.
 * 
 * @param field    Echo field with all returns
 * @param freq_hz  Frequency to compute interference at
 * @return         Interference field magnitude at this frequency
 */
float ag_harmonic_interference(const ss_echo_field_t* field, float freq_hz) {
    float sum_real = 0.0f;
    float sum_imag = 0.0f;
    
    for (int j = 0; j < field->count; j++) {
        const ss_echo_return_t* echo = &field->returns[j];
        
        /* Phase from round-trip delay */
        /* φⱼ = 2π · f · τⱼ where τⱼ = 2·dⱼ/c */
        float phase = 2.0f * M_PI * freq_hz * echo->delay_s;
        
        /* Amplitude after attenuation */
        float Aj = echo->amplitude;
        
        /* Equation 3: Hᵢ = |Σ Aⱼ · e^(iφⱼ)| */
        sum_real += Aj * cosf(phase);
        sum_imag += Aj * sinf(phase);
    }
    
    /* Magnitude of complex sum */
    return sqrtf(sum_real * sum_real + sum_imag * sum_imag);
}

/**
 * Compute the full interference spectrum across the three bands.
 * This produces the 3-band acoustic grammar that the brain decodes.
 */
void ag_compute_interference_spectrum(
    const ss_echo_field_t* field,
    float* band_low,    /* 125–500 Hz: geometry */
    float* band_mid,    /* 500–2000 Hz: crowd */
    float* band_high    /* 2000–8000 Hz: material */
) {
    /* Low band: room geometry / volume */
    *band_low = 0.0f;
    for (float f = 125.0f; f <= 500.0f; f += 25.0f) {
        *band_low += ag_harmonic_interference(field, f);
    }
    *band_low /= 16.0f; /* Normalize */
    
    /* Mid band: crowd density / moving bodies */
    *band_mid = 0.0f;
    for (float f = 500.0f; f <= 2000.0f; f += 100.0f) {
        *band_mid += ag_harmonic_interference(field, f);
    }
    *band_mid /= 16.0f;
    
    /* High band: surface material / texture */
    *band_high = 0.0f;
    for (float f = 2000.0f; f <= 8000.0f; f += 400.0f) {
        *band_high += ag_harmonic_interference(field, f);
    }
    *band_high /= 16.0f;
}

/* ═══════════════════════════════════════════════════════════
 * EQUATION 4: ENVIRONMENTAL CHANNEL MODEL
 * α(f,H) = k · f² · e^(−βH)
 * ═══════════════════════════════════════════════════════════ */

/**
 * Environmental channel model — humidity-dependent attenuation.
 * Equivalent to 5G mmWave propagation models (ITU-R P.676).
 * 
 * High humidity → more attenuation at high frequencies → 
 * material textures become harder to discriminate → 
 * system needs to compensate by boosting high band.
 * 
 * @param freq_hz      Signal frequency
 * @param humidity_pct Relative humidity (0–100)
 * @return             Environmental attenuation factor
 */
float ag_environmental_channel(float freq_hz, float humidity_pct) {
    /* Equation 4: α(f,H) = k · f² · e^(−βH) */
    float k = 1.17e-5f;
    float beta = 0.03f;       /* Humidity sensitivity coefficient */
    float H = humidity_pct;
    
    float alpha = k * freq_hz * freq_hz * expf(-beta * H);
    
    return alpha;
}

/**
 * Apply full environmental correction to the echo field.
 * Combines atmospheric attenuation (Eq. 2) with humidity (Eq. 4).
 */
void ag_apply_environmental_correction(ss_echo_field_t* field,
                                        float temperature_c,
                                        float humidity_pct) {
    field->temperature_c = temperature_c;
    field->humidity_pct = humidity_pct;
    
    /* Compute aggregate atmospheric factor */
    field->atmo_factor = ag_environmental_channel(
        2000.0f, /* Reference frequency */
        humidity_pct
    );
    
    /* Adjust each echo return */
    for (int i = 0; i < field->count; i++) {
        ss_echo_return_t* echo = &field->returns[i];
        
        const ss_material_props_t* mat = &MATERIAL_TABLE[echo->material];
        float f_center = (mat->freq_band_low + mat->freq_band_high) / 2.0f;
        
        /* Combined attenuation: atmospheric + environmental */
        float env_atten = ag_environmental_channel(f_center, humidity_pct);
        echo->amplitude *= expf(-env_atten * echo->distance_m);
    }
}

/* ═══════════════════════════════════════════════════════════
 * MATERIAL CLASSIFICATION FROM ECHO SPECTRUM
 * Uses FFT sub-band analysis to identify surface materials
 * ═══════════════════════════════════════════════════════════ */

/**
 * Classify material type from echo spectral signature.
 * Each material has a characteristic frequency response:
 *   - Concrete/stone: strong low-frequency reflection
 *   - Glass/metal: strong high-frequency reflection  
 *   - Wood: warm mid-frequency resonance
 *   - Foliage: diffuse, heavily absorbed
 * 
 * This is the "what is that surface made of?" processor.
 */
ss_material_t ag_classify_material(const float* echo_spectrum, int n_bins,
                                    float sample_rate) {
    /* Compute energy in three sub-bands */
    float energy_low = 0, energy_mid = 0, energy_high = 0;
    float freq_per_bin = sample_rate / (float)(n_bins * 2);
    
    for (int i = 0; i < n_bins; i++) {
        float freq = (float)i * freq_per_bin;
        float mag = echo_spectrum[i] * echo_spectrum[i];
        
        if (freq < 500.0f)       energy_low += mag;
        else if (freq < 2000.0f) energy_mid += mag;
        else if (freq < 8000.0f) energy_high += mag;
    }
    
    /* Normalize */
    float total = energy_low + energy_mid + energy_high + 1e-10f;
    float r_low  = energy_low / total;
    float r_mid  = energy_mid / total;
    float r_high = energy_high / total;
    
    /* Classification rules (simplified; production uses NPU inference) */
    if (r_low > 0.6f && r_high < 0.15f) {
        return (r_low > 0.75f) ? MAT_CONCRETE : MAT_STONE;
    }
    if (r_high > 0.5f && r_low < 0.15f) {
        return (r_high > 0.7f) ? MAT_METAL : MAT_GLASS;
    }
    if (r_mid > 0.5f) {
        /* Mid-band dominant — could be wood, foliage, or human */
        if (total < 0.3f) return MAT_FOLIAGE;  /* High absorption */
        if (total < 0.5f) return MAT_HUMAN;
        return MAT_WOOD;
    }
    if (r_high > 0.3f && r_low < 0.3f) {
        return MAT_WATER;
    }
    
    return MAT_UNKNOWN;
}

/* ═══════════════════════════════════════════════════════════
 * RAY CASTING — Point Cloud → Echo Prediction
 * Given user position + click direction, compute expected echoes
 * ═══════════════════════════════════════════════════════════ */

/**
 * Cast acoustic rays through the voxel grid to predict echo returns.
 * This is where LiDAR point cloud data becomes acoustic prediction.
 * 
 * For each ray in the click's propagation cone:
 *   1. March through voxel grid
 *   2. Find first occupied voxel (surface hit)
 *   3. Compute distance, reflection angle, material
 *   4. Generate predicted echo return
 * 
 * The predicted echo is what the device synthesizes and delivers
 * through bone conduction — augmenting the natural echo.
 */
int ag_ray_cast(
    const ss_voxel_grid_t* grid,
    float origin_x, float origin_y, float origin_z,
    float head_yaw, float head_pitch,
    ss_echo_field_t* echo_field
) {
    echo_field->count = 0;
    echo_field->click_time_us = ss_get_time_us();
    
    /* Propagation cone: ±60° horizontal, ±30° vertical */
    float cone_h = M_PI / 3.0f;   /* 60° half-angle horizontal */
    float cone_v = M_PI / 6.0f;   /* 30° half-angle vertical */
    
    int h_rays = 24;  /* Horizontal ray count */
    int v_rays = 8;   /* Vertical ray count */
    
    for (int ih = 0; ih < h_rays; ih++) {
        float azimuth = head_yaw - cone_h + 
                        (2.0f * cone_h * (float)ih / (float)(h_rays - 1));
        
        for (int iv = 0; iv < v_rays; iv++) {
            float elevation = head_pitch - cone_v +
                              (2.0f * cone_v * (float)iv / (float)(v_rays - 1));
            
            /* Ray direction */
            float dx = cosf(elevation) * cosf(azimuth);
            float dy = cosf(elevation) * sinf(azimuth);
            float dz = sinf(elevation);
            
            /* March through voxel grid */
            float step = VOXEL_SIZE_M * 0.5f;
            float max_dist = LIDAR_RANGE_M;
            
            for (float t = 0.3f; t < max_dist; t += step) {
                float px = origin_x + dx * t;
                float py = origin_y + dy * t;
                float pz = origin_z + dz * t;
                
                /* World → voxel index */
                int vx = (int)((px - grid->origin_x) / VOXEL_SIZE_M);
                int vy = (int)((py - grid->origin_y) / VOXEL_SIZE_M);
                int vz = (int)((pz - grid->origin_z) / VOXEL_SIZE_M);
                
                if (vx < 0 || vx >= VOXEL_GRID_X ||
                    vy < 0 || vy >= VOXEL_GRID_Y ||
                    vz < 0 || vz >= VOXEL_GRID_Z) {
                    break; /* Outside grid */
                }
                
                const ss_voxel_t* cell = &grid->cells[vx][vy][vz];
                
                if (cell->occupancy > 0.5f) {
                    /* ── Surface hit! Create echo return ── */
                    if (echo_field->count >= 256) goto done;
                    
                    ss_echo_return_t* echo = 
                        &echo_field->returns[echo_field->count];
                    
                    echo->distance_m = t;
                    echo->azimuth_rad = azimuth - head_yaw;
                    echo->elevation_rad = elevation - head_pitch;
                    echo->material = (ss_material_t)cell->material_id;
                    
                    /* Round-trip delay */
                    echo->delay_s = 2.0f * t / SPEED_OF_SOUND_MS;
                    
                    /* Initial amplitude (before attenuation) */
                    /* Inversely proportional to distance² (spherical spreading) */
                    echo->amplitude = cell->reflectivity / (t * t + 0.01f);
                    
                    echo_field->count++;
                    break; /* This ray found a surface, move to next */
                }
            }
        }
    }
    
done:
    /* Apply atmospheric attenuation to all returns */
    ag_apply_attenuation(echo_field);
    
    /* Compute harmonic interference (Equation 3) */
    echo_field->harmonic_field = ag_harmonic_interference(
        echo_field, 1000.0f /* Reference frequency */
    );
    
    return echo_field->count;
}
