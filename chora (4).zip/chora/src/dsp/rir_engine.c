/**
 * Chōra — Room Impulse Response (RIR) Engine + HRTF Renderer
 * 
 * The hardest engineering problem in the system.
 * 
 * Given a LiDAR point cloud and a click onset, this module:
 *   1. Predicts the Room Impulse Response (what echoes SHOULD sound like)
 *   2. Synthesizes a binaural augmented echo using HRTF spatialization
 *   3. Delivers it through bone conduction speakers
 * 
 * Budget: RIR synthesis (1.5ms) + HRTF render (1.0ms) = 2.5ms total
 * 
 * This has been done in offline acoustic simulation for decades.
 * Doing it on wearable hardware in <2.5ms is the novel contribution.
 */

#include "core/pipeline.h"
#include "dsp/rir_engine.h"
#include "dsp/acoustic_grammar.h"
#include <math.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════
 * RIR CONFIGURATION
 * ═══════════════════════════════════════════════════════════ */

#define RIR_MAX_LENGTH      512     /* Max impulse response samples */
#define RIR_SAMPLE_RATE     48000   /* Must match audio output */
#define RIR_MAX_REFLECTIONS 64      /* Max reflection paths to model */
#define HRTF_FILTER_LEN     128     /* HRTF FIR filter taps */
#define HRTF_DIRECTIONS     72      /* 5° azimuth resolution */

/* ═══════════════════════════════════════════════════════════
 * HRTF DATABASE (Pre-measured head-related transfer functions)
 * Each entry is a binaural FIR filter for one direction.
 * Production uses personalized HRTFs; prototype uses CIPIC/MIT KEMAR.
 * ═══════════════════════════════════════════════════════════ */

typedef struct {
    float azimuth_deg;
    float elevation_deg;
    float left_fir[HRTF_FILTER_LEN];
    float right_fir[HRTF_FILTER_LEN];
} hrtf_entry_t;

/* HRTF lookup table — 72 azimuth × 1 elevation (horizontal plane) */
static hrtf_entry_t hrtf_table[HRTF_DIRECTIONS];
static bool hrtf_loaded = false;

/**
 * Initialize HRTF table with simplified analytical model.
 * Production: load measured HRTF from flash storage.
 * 
 * The HRTF encodes how sound from a specific direction is modified
 * by the head, pinnae (outer ears), and torso before reaching the
 * eardrums. For bone conduction, we adapt the HRTF to account for
 * the different transduction path (skull vibration vs air conduction).
 */
void rir_init_hrtf(void) {
    for (int i = 0; i < HRTF_DIRECTIONS; i++) {
        float az_deg = (float)i * (360.0f / HRTF_DIRECTIONS) - 180.0f;
        float az_rad = az_deg * M_PI / 180.0f;
        
        hrtf_table[i].azimuth_deg = az_deg;
        hrtf_table[i].elevation_deg = 0.0f;
        
        for (int t = 0; t < HRTF_FILTER_LEN; t++) {
            float time_s = (float)t / (float)RIR_SAMPLE_RATE;
            
            /*
             * Simplified HRTF model (Woodworth spherical head):
             *   ITD (interaural time difference) = (a/c)(θ + sin(θ))
             *   ILD (interaural level difference) ∝ frequency × head shadow
             * 
             * a = head radius (~0.0875m)
             * c = speed of sound
             * θ = azimuth angle
             */
            float head_radius = 0.0875f;
            float itd = (head_radius / SPEED_OF_SOUND_MS) * 
                        (az_rad + sinf(az_rad));
            
            /* Left ear: leading for sources on the left (negative azimuth) */
            float delay_left = fmaxf(0.0f, -itd);
            float delay_right = fmaxf(0.0f, itd);
            
            /* Head shadow effect (ILD): ipsilateral ear is louder */
            float shadow_left = 1.0f + 0.3f * sinf(az_rad);   /* Louder when source is left */
            float shadow_right = 1.0f - 0.3f * sinf(az_rad);  /* Louder when source is right */
            
            /* Construct minimum-phase FIR approximation */
            float t_left = time_s - delay_left;
            float t_right = time_s - delay_right;
            
            /* Decaying sinc function convolved with head shadow */
            if (t_left > 0 && t_left < 0.002f) {
                float env = expf(-t_left * 2000.0f);
                hrtf_table[i].left_fir[t] = env * shadow_left *
                    sinf(2.0f * M_PI * 4000.0f * t_left);
            } else {
                hrtf_table[i].left_fir[t] = 0.0f;
            }
            
            if (t_right > 0 && t_right < 0.002f) {
                float env = expf(-t_right * 2000.0f);
                hrtf_table[i].right_fir[t] = env * shadow_right *
                    sinf(2.0f * M_PI * 4000.0f * t_right);
            } else {
                hrtf_table[i].right_fir[t] = 0.0f;
            }
        }
    }
    
    hrtf_loaded = true;
}

/**
 * Find nearest HRTF entry for a given azimuth angle.
 */
static const hrtf_entry_t* hrtf_lookup(float azimuth_rad) {
    float az_deg = azimuth_rad * 180.0f / M_PI;
    /* Wrap to [-180, 180] */
    while (az_deg > 180.0f)  az_deg -= 360.0f;
    while (az_deg < -180.0f) az_deg += 360.0f;
    
    int idx = (int)((az_deg + 180.0f) / (360.0f / HRTF_DIRECTIONS));
    idx = idx % HRTF_DIRECTIONS;
    if (idx < 0) idx += HRTF_DIRECTIONS;
    
    return &hrtf_table[idx];
}

/* ═══════════════════════════════════════════════════════════
 * RIR SYNTHESIS
 * Predicts Room Impulse Response from echo field data
 * ═══════════════════════════════════════════════════════════ */

/** RIR state buffer */
static float rir_buffer[RIR_MAX_LENGTH];

/**
 * Synthesize Room Impulse Response from echo field.
 * 
 * Each echo return contributes a delayed, attenuated, filtered impulse
 * to the RIR. The composite RIR describes how the room transforms
 * the click into the series of echoes the user should hear.
 * 
 * This is the "ground truth" signal that teaches the brain what
 * the space actually sounds like.
 * 
 * @param field    Echo field with distances, amplitudes, materials
 * @param rir      Output buffer (RIR_MAX_LENGTH samples at 48kHz)
 * @return         Length of significant RIR (samples)
 */
int rir_synthesize(const ss_echo_field_t* field, float* rir) {
    memset(rir, 0, RIR_MAX_LENGTH * sizeof(float));
    
    for (int i = 0; i < field->count && i < RIR_MAX_REFLECTIONS; i++) {
        const ss_echo_return_t* echo = &field->returns[i];
        
        /* Convert delay to sample index */
        int delay_samples = (int)(echo->delay_s * RIR_SAMPLE_RATE);
        if (delay_samples < 0 || delay_samples >= RIR_MAX_LENGTH - 32) {
            continue;
        }
        
        /* Get material properties for spectral shaping */
        const ss_material_props_t* mat = &MATERIAL_TABLE[echo->material];
        
        /* 
         * Each reflection is a filtered impulse:
         *   - Amplitude from inverse-square law + material absorption
         *   - Spectral shape from material frequency response
         *   - Scatter from surface roughness
         */
        
        float amplitude = echo->amplitude;
        
        /* Apply material-specific spectral filtering */
        float f_low  = mat->freq_band_low;
        float f_high = mat->freq_band_high;
        float f_center = (f_low + f_high) / 2.0f;
        
        /* Generate filtered impulse at the delay position */
        for (int t = 0; t < 32; t++) {
            int idx = delay_samples + t;
            if (idx >= RIR_MAX_LENGTH) break;
            
            float time_s = (float)t / (float)RIR_SAMPLE_RATE;
            
            /* Damped sinusoid at material's center frequency */
            float decay_rate = 1000.0f * (1.0f + mat->absorption_coeff * 5.0f);
            float envelope = amplitude * expf(-time_s * decay_rate);
            
            /* Spectral content: band-limited to material's frequency range */
            float signal = envelope * sinf(2.0f * M_PI * f_center * time_s);
            
            /* Add scatter (randomized low-amplitude reflections) */
            if (mat->scatter_coeff > 0.1f) {
                float scatter = mat->scatter_coeff * envelope * 0.3f *
                    sinf(2.0f * M_PI * f_center * 1.37f * time_s);
                signal += scatter;
            }
            
            rir[idx] += signal;
        }
    }
    
    /* Find effective RIR length (last sample above noise floor) */
    int rir_length = 0;
    for (int i = RIR_MAX_LENGTH - 1; i >= 0; i--) {
        if (fabsf(rir[i]) > 1e-5f) {
            rir_length = i + 1;
            break;
        }
    }
    
    return rir_length;
}

/* ═══════════════════════════════════════════════════════════
 * BINAURAL RENDERING (HRTF Spatialization)
 * Converts mono RIR into left/right bone conduction signals
 * ═══════════════════════════════════════════════════════════ */

/**
 * Render binaural audio from echo field using HRTF spatialization.
 * 
 * Each echo return is individually spatialized to its azimuth/elevation,
 * then all spatialized echoes are summed into the binaural output.
 * 
 * The result: the user hears echoes coming from the correct 3D directions,
 * delivered through bone conduction at the cheekbones.
 * 
 * @param field          Echo field with spatial returns
 * @param output         Binaural audio output frame
 * @param augmentation   Training scaffold: 0.0–1.0 amplitude scaling
 */
void rir_render_binaural(
    const ss_echo_field_t* field,
    ss_audio_frame_t* output,
    float augmentation
) {
    if (!hrtf_loaded) return;
    
    memset(output->left, 0, AUDIO_BLOCK_SIZE * sizeof(float));
    memset(output->right, 0, AUDIO_BLOCK_SIZE * sizeof(float));
    output->timestamp_us = ss_get_time_us();
    
    for (int i = 0; i < field->count && i < RIR_MAX_REFLECTIONS; i++) {
        const ss_echo_return_t* echo = &field->returns[i];
        
        /* Look up HRTF for this echo's direction */
        const hrtf_entry_t* hrtf = hrtf_lookup(echo->azimuth_rad);
        
        /* Convert delay to sample offset */
        int onset = (int)(echo->delay_s * RIR_SAMPLE_RATE);
        if (onset >= AUDIO_BLOCK_SIZE) continue;
        
        /* Material-dependent spectral content */
        const ss_material_props_t* mat = &MATERIAL_TABLE[echo->material];
        float f_center = (mat->freq_band_low + mat->freq_band_high) / 2.0f;
        
        /* Generate the echo impulse */
        float amp = echo->amplitude * augmentation;
        
        for (int t = 0; t < 32 && (onset + t) < AUDIO_BLOCK_SIZE; t++) {
            int idx = onset + t;
            float time_s = (float)t / (float)RIR_SAMPLE_RATE;
            
            /* Damped oscillation at material frequency */
            float decay = expf(-time_s * 800.0f * (1.0f + mat->absorption_coeff));
            float mono_sample = amp * decay * sinf(2.0f * M_PI * f_center * time_s);
            
            /* 
             * Apply HRTF: convolve with direction-specific filters.
             * Simplified: use first few taps of FIR for real-time budget.
             */
            int hrtf_taps = (t < HRTF_FILTER_LEN) ? 8 : 0; /* Truncated for speed */
            float left_spat = 0, right_spat = 0;
            
            for (int h = 0; h < hrtf_taps && (t - h) >= 0; h++) {
                left_spat  += mono_sample * hrtf->left_fir[h];
                right_spat += mono_sample * hrtf->right_fir[h];
            }
            
            /* If no HRTF taps applied, use simple panning */
            if (hrtf_taps == 0) {
                float pan = sinf(echo->azimuth_rad);
                left_spat  = mono_sample * (0.5f - 0.5f * pan);
                right_spat = mono_sample * (0.5f + 0.5f * pan);
            }
            
            output->left[idx]  += left_spat;
            output->right[idx] += right_spat;
        }
    }
    
    /* ── Soft-clip to prevent bone conduction overload ── */
    for (int i = 0; i < AUDIO_BLOCK_SIZE; i++) {
        output->left[i]  = tanhf(output->left[i] * 2.0f) * 0.5f;
        output->right[i] = tanhf(output->right[i] * 2.0f) * 0.5f;
    }
}

/* ═══════════════════════════════════════════════════════════
 * THREE-BAND ACOUSTIC GRAMMAR SYNTHESIS
 * Produces the structured signal that trains the visual cortex
 * ═══════════════════════════════════════════════════════════ */

/**
 * Synthesize the three-band acoustic grammar signal.
 * This is the core teaching signal:
 *   - Low band oscillation  → "how big is the room?"
 *   - Mid band density      → "how many people/objects?"
 *   - High band texture     → "what are surfaces made of?"
 * 
 * Mixed into the binaural output before bone conduction delivery.
 */
void rir_synthesize_grammar(
    const ss_echo_field_t* field,
    ss_audio_frame_t* output,
    float augmentation
) {
    /* Compute three-band energies from interference spectrum */
    float band_low, band_mid, band_high;
    ag_compute_interference_spectrum(field, &band_low, &band_mid, &band_high);
    
    /* Scale by augmentation (training scaffold) */
    band_low  *= augmentation;
    band_mid  *= augmentation;
    band_high *= augmentation;
    
    /* Synthesize continuous tonal carriers for each band */
    for (int i = 0; i < AUDIO_BLOCK_SIZE; i++) {
        float t = (float)i / (float)RIR_SAMPLE_RATE;
        
        /* Low band: 250Hz drone → room geometry */
        float low_signal = band_low * 0.3f * sinf(2.0f * M_PI * 250.0f * t);
        
        /* Mid band: 1000Hz pulse → crowd density */
        float mid_signal = band_mid * 0.2f * sinf(2.0f * M_PI * 1000.0f * t);
        
        /* High band: 4000Hz shimmer → material texture */
        float high_signal = band_high * 0.15f * sinf(2.0f * M_PI * 4000.0f * t);
        
        /* Mix into output (additive with spatialized echoes) */
        float grammar = low_signal + mid_signal + high_signal;
        output->left[i]  += grammar * 0.5f;
        output->right[i] += grammar * 0.5f;
    }
}
