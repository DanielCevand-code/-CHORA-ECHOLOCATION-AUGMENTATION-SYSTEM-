/**
 * Chōra — MEMS Ultrasonic & Click Detection Driver
 * 
 * Handles two subsystems:
 * 1. MEMS Ultrasonic TX/RX (Murata MA40S4S, 40kHz):
 *    - Generates frequency-modulated chirps for active echolocation
 *    - Captures echo returns with microsecond TDoA precision
 *    - Computes Time-of-Arrival distance (Equation 1: d = c·Δτ/2)
 * 
 * 2. MEMS Microphone Array (Knowles SPH0645):
 *    - Detects user's mouth clicks and tongue clicks
 *    - Measures click onset with <0.5ms precision
 *    - Classifies click type (tongue/mouth/finger)
 *    - Captures natural echo returns for training correlation
 * 
 * The click detection is the most critical timing path:
 * the user's click triggers the entire 8ms pipeline.
 */

#include "core/pipeline.h"
#include "drivers/mems.h"
#include <string.h>

/* ═══════════════════════════════════════════════════════════
 * HARDWARE CONFIGURATION
 * ═══════════════════════════════════════════════════════════ */

/* MEMS Ultrasonic Transducers (Temple-mounted) */
#define MEMS_TX_LEFT_GPIO       12     /* Left TX enable pin */
#define MEMS_TX_RIGHT_GPIO      13     /* Right TX enable pin */
#define MEMS_RX_LEFT_ADC        0      /* Left RX ADC channel */
#define MEMS_RX_RIGHT_ADC       1      /* Right RX ADC channel */
#define MEMS_TX_FREQ_HZ         40000  /* 40kHz center frequency */
#define MEMS_CHIRP_DURATION_US  200    /* 200μs chirp length */
#define MEMS_CHIRP_BW_HZ        4000   /* 38–42kHz sweep bandwidth */
#define MEMS_ADC_SAMPLE_RATE    200000 /* 200kHz ADC for ultrasonic */

/* MEMS Microphone (Lower frame, click detection) */
#define MIC_LEFT_PDM_CLK        14     /* PDM clock pin */
#define MIC_LEFT_PDM_DATA       15     /* PDM data pin */
#define MIC_RIGHT_PDM_CLK       16
#define MIC_RIGHT_PDM_DATA      17
#define MIC_SAMPLE_RATE         48000  /* 48kHz for audio-band capture */
#define MIC_PDM_RATIO           64     /* PDM decimation ratio */

/* Click detection parameters */
#define CLICK_ENERGY_THRESHOLD  0.15f  /* RMS energy threshold */
#define CLICK_MIN_FREQ_HZ       1500   /* Clicks are >1.5kHz */
#define CLICK_MAX_DURATION_MS   15.0f  /* Clicks are <15ms */
#define CLICK_DEBOUNCE_MS       200    /* Minimum inter-click interval */

/* ═══════════════════════════════════════════════════════════
 * DRIVER STATE
 * ═══════════════════════════════════════════════════════════ */

typedef struct {
    /* Ultrasonic state */
    bool     us_initialized;
    float    chirp_waveform[128];     /* Pre-computed chirp samples */
    float    rx_buffer_left[512];     /* Left RX capture buffer */
    float    rx_buffer_right[512];    /* Right RX capture buffer */
    uint32_t last_tx_time_us;         /* Last chirp transmission */
    
    /* Click detection state */
    bool     mic_initialized;
    float    mic_buffer[1024];        /* Rolling audio buffer */
    int      mic_write_pos;           /* Circular buffer position */
    float    energy_history[32];      /* Rolling RMS energy */
    int      energy_pos;
    float    baseline_energy;         /* Ambient noise floor */
    uint32_t last_click_time_us;      /* Debounce tracking */
    bool     click_armed;             /* Ready for next click */
    
    /* Environmental */
    float    speed_of_sound;          /* Temperature-corrected */
} mems_state_t;

static mems_state_t mems = {0};

/* ═══════════════════════════════════════════════════════════
 * CHIRP WAVEFORM GENERATION
 * Linear frequency-modulated chirp: 38kHz → 42kHz in 200μs
 * ═══════════════════════════════════════════════════════════ */

/**
 * Pre-compute the FM chirp waveform at initialization.
 * This chirp is transmitted by the MEMS ultrasonic transducers
 * and its echo is cross-correlated with the RX signal for
 * precise time-of-arrival measurement.
 */
static void mems_generate_chirp(void) {
    float f0 = (float)(MEMS_TX_FREQ_HZ - MEMS_CHIRP_BW_HZ / 2);
    float f1 = (float)(MEMS_TX_FREQ_HZ + MEMS_CHIRP_BW_HZ / 2);
    float duration = (float)MEMS_CHIRP_DURATION_US / 1e6f;
    int n_samples = 128;
    float dt = duration / (float)n_samples;
    
    for (int i = 0; i < n_samples; i++) {
        float t = (float)i * dt;
        /* Linear chirp: instantaneous frequency sweeps f0→f1 */
        float freq = f0 + (f1 - f0) * t / duration;
        float phase = 2.0f * M_PI * (f0 * t + 0.5f * (f1 - f0) * t * t / duration);
        
        /* Apply Hann window to reduce spectral leakage */
        float window = 0.5f * (1.0f - cosf(2.0f * M_PI * i / (n_samples - 1)));
        
        mems.chirp_waveform[i] = sinf(phase) * window;
    }
}

/* ═══════════════════════════════════════════════════════════
 * INITIALIZATION
 * ═══════════════════════════════════════════════════════════ */

int mems_ultrasonic_init(void) {
    /* Configure GPIO for TX enable */
    ss_gpio_configure(MEMS_TX_LEFT_GPIO, GPIO_OUTPUT);
    ss_gpio_configure(MEMS_TX_RIGHT_GPIO, GPIO_OUTPUT);
    ss_gpio_write(MEMS_TX_LEFT_GPIO, 0);
    ss_gpio_write(MEMS_TX_RIGHT_GPIO, 0);
    
    /* Configure ADC for RX capture */
    ss_adc_init(MEMS_RX_LEFT_ADC, MEMS_ADC_SAMPLE_RATE);
    ss_adc_init(MEMS_RX_RIGHT_ADC, MEMS_ADC_SAMPLE_RATE);
    
    /* Pre-compute chirp waveform */
    mems_generate_chirp();
    
    /* Temperature-corrected speed of sound */
    mems.speed_of_sound = SPEED_OF_SOUND_MS;
    
    mems.us_initialized = true;
    return 0;
}

int mems_microphone_init(void) {
    /* Configure PDM interface for both microphones */
    ss_pdm_init(MIC_LEFT_PDM_CLK, MIC_LEFT_PDM_DATA, 
                MIC_SAMPLE_RATE, MIC_PDM_RATIO);
    ss_pdm_init(MIC_RIGHT_PDM_CLK, MIC_RIGHT_PDM_DATA,
                MIC_SAMPLE_RATE, MIC_PDM_RATIO);
    
    /* Initialize click detection state */
    mems.mic_write_pos = 0;
    mems.energy_pos = 0;
    mems.baseline_energy = 0.01f;
    mems.click_armed = true;
    mems.last_click_time_us = 0;
    
    memset(mems.mic_buffer, 0, sizeof(mems.mic_buffer));
    memset(mems.energy_history, 0, sizeof(mems.energy_history));
    
    mems.mic_initialized = true;
    return 0;
}

/* ═══════════════════════════════════════════════════════════
 * ULTRASONIC ECHO CAPTURE
 * Transmits chirp → captures echo → cross-correlates for ToA
 * ═══════════════════════════════════════════════════════════ */

/**
 * Cross-correlation between transmitted chirp and received echo.
 * Finds the time delay (τ) of the strongest echo return.
 * Returns distance via Equation 1: d = c · Δτ / 2
 */
static float mems_cross_correlate(
    const float* tx_ref, int tx_len,
    const float* rx_signal, int rx_len,
    float* peak_amplitude
) {
    float max_corr = 0.0f;
    int max_lag = 0;
    
    int max_search = rx_len - tx_len;
    if (max_search <= 0) return -1.0f;
    
    for (int lag = 0; lag < max_search; lag++) {
        float corr = 0.0f;
        for (int i = 0; i < tx_len; i++) {
            corr += tx_ref[i] * rx_signal[lag + i];
        }
        if (corr > max_corr) {
            max_corr = corr;
            max_lag = lag;
        }
    }
    
    *peak_amplitude = max_corr / (float)tx_len;
    
    /* Convert lag to time delay, then to distance */
    /* Equation 1: d = c · Δτ / 2 */
    float dt = (float)max_lag / (float)MEMS_ADC_SAMPLE_RATE;
    float distance = mems.speed_of_sound * dt / 2.0f;
    
    return distance;
}

/**
 * Perform one ultrasonic echo measurement cycle.
 * TX chirp → wait → RX capture → cross-correlate → distance.
 */
int mems_echo_measure(float* dist_left, float* dist_right,
                       float* amp_left, float* amp_right) {
    if (!mems.us_initialized) return -1;
    
    /* ── Transmit chirp on both TX simultaneously ── */
    uint32_t tx_time = ss_get_time_us();
    
    /* Enable TX and output chirp via DAC/PWM */
    ss_gpio_write(MEMS_TX_LEFT_GPIO, 1);
    ss_gpio_write(MEMS_TX_RIGHT_GPIO, 1);
    
    /* Output chirp waveform via timer-driven DAC */
    for (int i = 0; i < 128; i++) {
        ss_dac_write(0, (uint16_t)((mems.chirp_waveform[i] + 1.0f) * 2048));
        ss_delay_us(1); /* ~200μs total chirp duration */
    }
    
    ss_gpio_write(MEMS_TX_LEFT_GPIO, 0);
    ss_gpio_write(MEMS_TX_RIGHT_GPIO, 0);
    
    mems.last_tx_time_us = tx_time;
    
    /* ── Capture echo returns ── */
    /* Wait for ringdown (direct path, ~2ms for 0.3m separation) */
    ss_delay_us(500);
    
    /* DMA-driven ADC capture: 512 samples at 200kHz = 2.56ms */
    ss_adc_capture_dma(MEMS_RX_LEFT_ADC, mems.rx_buffer_left, 512);
    ss_adc_capture_dma(MEMS_RX_RIGHT_ADC, mems.rx_buffer_right, 512);
    
    /* Wait for capture complete */
    ss_adc_wait_complete();
    
    /* ── Cross-correlate for distance ── */
    *dist_left = mems_cross_correlate(
        mems.chirp_waveform, 128,
        mems.rx_buffer_left, 512,
        amp_left
    );
    
    *dist_right = mems_cross_correlate(
        mems.chirp_waveform, 128,
        mems.rx_buffer_right, 512,
        amp_right
    );
    
    return 0;
}

/**
 * Compute Time-Difference-of-Arrival (TDoA) between left and right RX.
 * Returns azimuth angle to the reflecting surface.
 * Used for spatial direction estimation independent of LiDAR.
 */
float mems_compute_tdoa_angle(void) {
    /* Find peak in left and right correlation */
    float max_l = 0, max_r = 0;
    int lag_l = 0, lag_r = 0;
    
    for (int i = 0; i < 512; i++) {
        float v = fabsf(mems.rx_buffer_left[i]);
        if (v > max_l) { max_l = v; lag_l = i; }
        v = fabsf(mems.rx_buffer_right[i]);
        if (v > max_r) { max_r = v; lag_r = i; }
    }
    
    /* Time difference */
    float tdoa_samples = (float)(lag_l - lag_r);
    float tdoa_seconds = tdoa_samples / (float)MEMS_ADC_SAMPLE_RATE;
    
    /* Baseline distance between sensors: ~0.14m (temple to temple) */
    float baseline_m = 0.14f;
    
    /* Azimuth angle: sin(θ) = c·Δt / baseline */
    float sin_theta = mems.speed_of_sound * tdoa_seconds / baseline_m;
    sin_theta = fmaxf(-1.0f, fminf(1.0f, sin_theta));
    
    return asinf(sin_theta);
}

/* ═══════════════════════════════════════════════════════════
 * CLICK DETECTION
 * Real-time detection of user's mouth/tongue clicks
 * This is the trigger that starts the entire pipeline
 * ═══════════════════════════════════════════════════════════ */

/**
 * Compute short-time RMS energy of audio block.
 */
static float compute_rms_energy(const float* samples, int count) {
    float sum = 0.0f;
    for (int i = 0; i < count; i++) {
        sum += samples[i] * samples[i];
    }
    return sqrtf(sum / (float)count);
}

/**
 * Simple peak frequency estimation using zero-crossing rate.
 * Full FFT would be more accurate but this is faster for onset detection.
 */
static float estimate_peak_frequency(const float* samples, int count, 
                                      float sample_rate) {
    int crossings = 0;
    for (int i = 1; i < count; i++) {
        if ((samples[i-1] >= 0 && samples[i] < 0) ||
            (samples[i-1] < 0 && samples[i] >= 0)) {
            crossings++;
        }
    }
    /* Zero crossing rate ≈ 2 × fundamental frequency */
    return (float)crossings * sample_rate / (2.0f * (float)count);
}

/**
 * Classify click type based on spectral and temporal characteristics.
 */
static ss_click_type_t classify_click(float energy, float peak_freq, 
                                       float duration_ms) {
    if (duration_ms > CLICK_MAX_DURATION_MS) return CLICK_NONE;
    if (energy < CLICK_ENERGY_THRESHOLD) return CLICK_NONE;
    
    /* Tongue clicks: very sharp transient, high frequency */
    if (peak_freq > 3000.0f && duration_ms < 5.0f) {
        return CLICK_TONGUE;
    }
    
    /* Finger snaps: broad spectrum, medium duration */
    if (energy > 0.4f && peak_freq > 2000.0f) {
        return CLICK_FINGER;
    }
    
    /* Mouth clicks: moderate frequency, moderate duration */
    if (peak_freq > CLICK_MIN_FREQ_HZ) {
        return CLICK_MOUTH;
    }
    
    return CLICK_NONE;
}

/**
 * Process incoming microphone samples and detect click events.
 * Called continuously at MIC_SAMPLE_RATE / block_size rate.
 * 
 * This function is interrupt-driven — it must complete in <0.5ms.
 * 
 * When a click is detected, it fills the click_event structure
 * and returns 1. The main pipeline loop checks this flag.
 */
int mems_detect_click(const float* mic_samples, int count,
                       ss_click_event_t* click_event) {
    if (!mems.mic_initialized) return -1;
    
    uint32_t now = ss_get_time_us();
    
    /* Store samples in circular buffer */
    for (int i = 0; i < count && i < 1024; i++) {
        mems.mic_buffer[mems.mic_write_pos] = mic_samples[i];
        mems.mic_write_pos = (mems.mic_write_pos + 1) % 1024;
    }
    
    /* Compute block energy */
    float energy = compute_rms_energy(mic_samples, count);
    
    /* Update energy history for adaptive threshold */
    mems.energy_history[mems.energy_pos] = energy;
    mems.energy_pos = (mems.energy_pos + 1) % 32;
    
    /* Compute baseline (moving average of quiet periods) */
    float sum = 0;
    for (int i = 0; i < 32; i++) sum += mems.energy_history[i];
    float avg_energy = sum / 32.0f;
    
    /* Adaptive threshold: 3× baseline energy */
    float threshold = fmaxf(CLICK_ENERGY_THRESHOLD, 
                            avg_energy * 3.0f);
    
    /* ── Click Detection Logic ── */
    click_event->is_valid = false;
    
    /* Check debounce */
    if ((now - mems.last_click_time_us) < (CLICK_DEBOUNCE_MS * 1000)) {
        return 0;
    }
    
    /* Energy spike detection */
    if (energy > threshold && mems.click_armed) {
        /* Found onset — analyze the click */
        float peak_freq = estimate_peak_frequency(
            mic_samples, count, (float)MIC_SAMPLE_RATE
        );
        
        /* Estimate click duration by finding energy decay */
        float duration_ms = 0;
        for (int i = 0; i < count; i++) {
            if (fabsf(mic_samples[i]) > threshold * 0.3f) {
                duration_ms = (float)(i + 1) * 1000.0f / (float)MIC_SAMPLE_RATE;
            }
        }
        
        /* Classify */
        ss_click_type_t type = classify_click(energy, peak_freq, duration_ms);
        
        if (type != CLICK_NONE) {
            click_event->type = type;
            click_event->onset_time_us = now;
            click_event->energy = energy;
            click_event->peak_freq_hz = peak_freq;
            click_event->duration_ms = duration_ms;
            click_event->is_valid = true;
            
            mems.last_click_time_us = now;
            mems.click_armed = false;
            
            return 1; /* Click detected! Pipeline should run. */
        }
    }
    
    /* Re-arm when energy drops below baseline */
    if (energy < threshold * 0.5f) {
        mems.click_armed = true;
    }
    
    return 0;
}

/* ═══════════════════════════════════════════════════════════
 * ENVIRONMENTAL CORRECTION
 * Temperature and humidity affect speed of sound
 * ═══════════════════════════════════════════════════════════ */

/**
 * Update speed of sound based on temperature.
 * v = 331.3 + 0.606 × T (°C)
 * Critical for accurate distance measurement.
 */
void mems_update_environment(float temperature_c, float humidity_pct) {
    /* Temperature correction */
    mems.speed_of_sound = 331.3f + 0.606f * temperature_c;
    
    /* Humidity has minor effect on speed (~0.1% at 100% RH) */
    /* but significant effect on high-frequency attenuation */
    /* (handled in acoustic_grammar.c, Equation 4) */
}
