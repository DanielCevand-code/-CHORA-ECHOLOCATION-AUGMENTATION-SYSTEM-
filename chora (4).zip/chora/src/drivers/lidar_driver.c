/**
 * Chōra — LiDAR Driver
 * 
 * Solid-state direct Time-of-Flight (dToF) LiDAR driver.
 * Two sensors mounted on inner top frame, angled ±15° outward.
 * Captures 3D point cloud at 20fps, 15m range, up to 2048 points/frame.
 * 
 * Interface: SPI @ 10MHz to Alif Ensemble E7
 * Power: 120mW combined (60mW per sensor)
 * 
 * This is the device's "eyes" — equivalent to the autonomous vehicle's
 * roof-mounted LiDAR array, but two 4.2×5mm solid-state modules.
 */

#include "core/pipeline.h"
#include "drivers/lidar.h"

/* ═══════════════════════════════════════════════════════════
 * HARDWARE REGISTERS (Solid-State dToF Module)
 * ═══════════════════════════════════════════════════════════ */

#define LIDAR_SPI_BASE          0x40003000
#define LIDAR_REG_CTRL          (LIDAR_SPI_BASE + 0x00)
#define LIDAR_REG_STATUS        (LIDAR_SPI_BASE + 0x04)
#define LIDAR_REG_DATA          (LIDAR_SPI_BASE + 0x08)
#define LIDAR_REG_CONFIG        (LIDAR_SPI_BASE + 0x0C)
#define LIDAR_REG_RANGE         (LIDAR_SPI_BASE + 0x10)

/* Configuration bits */
#define LIDAR_CTRL_ENABLE       (1 << 0)
#define LIDAR_CTRL_SINGLE_SHOT  (1 << 1)
#define LIDAR_CTRL_CONTINUOUS   (1 << 2)
#define LIDAR_CTRL_RESET        (1 << 7)
#define LIDAR_STATUS_READY      (1 << 0)
#define LIDAR_STATUS_DATA_VALID (1 << 1)
#define LIDAR_STATUS_OVERFLOW   (1 << 4)

/* Sensor geometry */
#define LIDAR_LEFT_ANGLE_RAD    (-0.2618f)  /* -15° offset */
#define LIDAR_RIGHT_ANGLE_RAD   (0.2618f)   /* +15° offset */
#define LIDAR_VERTICAL_FOV_RAD  (0.7854f)   /* ±22.5° vertical */
#define LIDAR_HORIZONTAL_FOV_RAD (1.0472f)  /* ±30° horizontal */

/* ═══════════════════════════════════════════════════════════
 * DRIVER STATE
 * ═══════════════════════════════════════════════════════════ */

typedef struct {
    bool     initialized;
    bool     left_active;
    bool     right_active;
    uint32_t frame_count;
    uint32_t error_count;
    float    temperature_c;       /* Sensor temperature for calibration */
    
    /* Raw data buffers */
    uint16_t raw_distance_mm[1024]; /* Per-sensor raw distances */
    uint8_t  raw_intensity[1024];   /* Per-sensor intensities */
    
    /* Calibration */
    float    range_offset_mm;      /* Factory calibration offset */
    float    crosstalk_correction; /* Optical crosstalk factor */
} lidar_state_t;

static lidar_state_t lidar_state = {0};

/* ═══════════════════════════════════════════════════════════
 * LOW-LEVEL SPI COMMUNICATION
 * ═══════════════════════════════════════════════════════════ */

/** Write to LiDAR register via SPI */
static inline void lidar_reg_write(uint32_t reg, uint32_t value) {
    volatile uint32_t* addr = (volatile uint32_t*)reg;
    *addr = value;
}

/** Read from LiDAR register via SPI */
static inline uint32_t lidar_reg_read(uint32_t reg) {
    volatile uint32_t* addr = (volatile uint32_t*)reg;
    return *addr;
}

/** Wait for sensor ready with timeout */
static int lidar_wait_ready(uint32_t timeout_us) {
    uint32_t start = ss_get_time_us();
    while ((ss_get_time_us() - start) < timeout_us) {
        if (lidar_reg_read(LIDAR_REG_STATUS) & LIDAR_STATUS_READY) {
            return 0;
        }
    }
    return -1; /* Timeout */
}

/* ═══════════════════════════════════════════════════════════
 * INITIALIZATION
 * ═══════════════════════════════════════════════════════════ */

int lidar_init(void) {
    /* Reset both sensors */
    lidar_reg_write(LIDAR_REG_CTRL, LIDAR_CTRL_RESET);
    ss_delay_us(1000);
    
    /* Configure range and timing */
    uint32_t config = 0;
    config |= (15 << 0);    /* Max range: 15 meters */
    config |= (20 << 8);    /* Frame rate: 20 fps */
    config |= (1  << 16);   /* Integration time: medium */
    config |= (2  << 20);   /* Averaging: 2x for noise reduction */
    lidar_reg_write(LIDAR_REG_CONFIG, config);
    
    /* Set continuous capture mode */
    lidar_reg_write(LIDAR_REG_CTRL, LIDAR_CTRL_ENABLE | LIDAR_CTRL_CONTINUOUS);
    
    /* Wait for first frame ready */
    if (lidar_wait_ready(50000) != 0) {
        lidar_state.error_count++;
        return -1;
    }
    
    lidar_state.initialized = true;
    lidar_state.left_active = true;
    lidar_state.right_active = true;
    lidar_state.frame_count = 0;
    
    return 0;
}

/* ═══════════════════════════════════════════════════════════
 * POINT CLOUD CAPTURE
 * Reads raw dToF data and converts to 3D points in device frame
 * ═══════════════════════════════════════════════════════════ */

/**
 * Convert raw sensor pixel (row, col, distance) to 3D point.
 * Uses pinhole model with sensor-specific angular offsets.
 */
static ss_point3d_t sensor_pixel_to_point(
    uint16_t row, uint16_t col,
    uint16_t distance_mm, uint8_t intensity,
    float sensor_angle_offset
) {
    ss_point3d_t pt;
    
    /* Convert pixel to angular coordinates */
    float h_angle = LIDAR_HORIZONTAL_FOV_RAD * 
                    ((float)col / 32.0f - 0.5f) * 2.0f + sensor_angle_offset;
    float v_angle = LIDAR_VERTICAL_FOV_RAD * 
                    ((float)row / 32.0f - 0.5f) * 2.0f;
    
    /* Spherical to Cartesian conversion */
    float range_m = (float)distance_mm / 1000.0f;
    
    /* Apply crosstalk correction */
    range_m -= lidar_state.crosstalk_correction * 
               (1.0f / (range_m + 0.01f));
    
    if (range_m < 0.1f || range_m > LIDAR_RANGE_M) {
        pt.distance = -1.0f; /* Invalid point marker */
        return pt;
    }
    
    pt.x = range_m * cosf(v_angle) * cosf(h_angle);
    pt.y = range_m * cosf(v_angle) * sinf(h_angle);
    pt.z = range_m * sinf(v_angle);
    pt.distance = range_m;
    pt.intensity = (float)intensity / 255.0f;
    pt.ring_id = row;
    
    return pt;
}

/**
 * Capture one complete point cloud frame from both sensors.
 * Called at 20Hz by the pipeline scheduler.
 * Budget: 2.0ms
 */
int lidar_capture_frame(ss_point_cloud_t* cloud) {
    if (!lidar_state.initialized) return -1;
    
    uint32_t t_start = ss_get_time_us();
    cloud->count = 0;
    cloud->timestamp_us = t_start;
    
    /* ── Read Left Sensor ── */
    if (lidar_state.left_active) {
        /* Trigger readout */
        lidar_reg_write(LIDAR_REG_CTRL, 
            LIDAR_CTRL_ENABLE | LIDAR_CTRL_SINGLE_SHOT);
        
        if (lidar_wait_ready(1500) == 0) {
            /* Read 32×32 depth map from sensor */
            for (int row = 0; row < 32 && cloud->count < 2048; row++) {
                for (int col = 0; col < 32; col++) {
                    /* Read distance and intensity via SPI DMA */
                    uint32_t raw = lidar_reg_read(LIDAR_REG_DATA);
                    uint16_t dist_mm = (raw >> 8) & 0xFFFF;
                    uint8_t  intens  = raw & 0xFF;
                    
                    if (dist_mm == 0 || dist_mm > 15000) continue;
                    
                    ss_point3d_t pt = sensor_pixel_to_point(
                        row, col, dist_mm, intens,
                        LIDAR_LEFT_ANGLE_RAD
                    );
                    
                    if (pt.distance > 0) {
                        cloud->points[cloud->count++] = pt;
                    }
                }
            }
        }
    }
    
    /* ── Read Right Sensor ── */
    if (lidar_state.right_active) {
        lidar_reg_write(LIDAR_REG_CTRL,
            LIDAR_CTRL_ENABLE | LIDAR_CTRL_SINGLE_SHOT);
        
        if (lidar_wait_ready(1500) == 0) {
            for (int row = 0; row < 32 && cloud->count < 2048; row++) {
                for (int col = 0; col < 32; col++) {
                    uint32_t raw = lidar_reg_read(LIDAR_REG_DATA);
                    uint16_t dist_mm = (raw >> 8) & 0xFFFF;
                    uint8_t  intens  = raw & 0xFF;
                    
                    if (dist_mm == 0 || dist_mm > 15000) continue;
                    
                    ss_point3d_t pt = sensor_pixel_to_point(
                        row, col, dist_mm, intens,
                        LIDAR_RIGHT_ANGLE_RAD
                    );
                    
                    if (pt.distance > 0) {
                        cloud->points[cloud->count++] = pt;
                    }
                }
            }
        }
    }
    
    lidar_state.frame_count++;
    
    /* Verify timing budget */
    uint32_t elapsed = ss_get_time_us() - t_start;
    if (elapsed > 2500) {
        lidar_state.error_count++;
    }
    
    return (cloud->count > 0) ? 0 : -1;
}

/* ═══════════════════════════════════════════════════════════
 * VOXELIZATION
 * Converts point cloud into 3D occupancy grid for ray casting
 * ═══════════════════════════════════════════════════════════ */

/**
 * Build voxel grid from point cloud.
 * Each voxel stores occupancy, estimated reflectivity, and material class.
 */
void lidar_voxelize(const ss_point_cloud_t* cloud, ss_voxel_grid_t* grid) {
    /* Clear grid */
    for (int x = 0; x < VOXEL_GRID_X; x++)
        for (int y = 0; y < VOXEL_GRID_Y; y++)
            for (int z = 0; z < VOXEL_GRID_Z; z++) {
                grid->cells[x][y][z].occupancy = 0.0f;
                grid->cells[x][y][z].reflectivity = 0.0f;
                grid->cells[x][y][z].material_id = MAT_UNKNOWN;
            }
    
    grid->origin_x = 0.0f;
    grid->origin_y = 0.0f;
    grid->origin_z = -1.0f; /* 1m below sensor height */
    
    /* Insert points into voxels */
    for (int i = 0; i < cloud->count; i++) {
        const ss_point3d_t* pt = &cloud->points[i];
        
        /* World → voxel coordinates */
        int vx = (int)((pt->x - grid->origin_x) / VOXEL_SIZE_M);
        int vy = (int)((pt->y - grid->origin_y) / VOXEL_SIZE_M);
        int vz = (int)((pt->z - grid->origin_z) / VOXEL_SIZE_M);
        
        if (vx < 0 || vx >= VOXEL_GRID_X) continue;
        if (vy < 0 || vy >= VOXEL_GRID_Y) continue;
        if (vz < 0 || vz >= VOXEL_GRID_Z) continue;
        
        ss_voxel_t* cell = &grid->cells[vx][vy][vz];
        
        /* Accumulate occupancy (saturate at 1.0) */
        cell->occupancy = fminf(cell->occupancy + 0.2f, 1.0f);
        
        /* Estimate reflectivity from LiDAR return intensity */
        cell->reflectivity = 0.7f * cell->reflectivity + 
                             0.3f * pt->intensity;
    }
}

/* ═══════════════════════════════════════════════════════════
 * SURFACE NORMAL ESTIMATION
 * Computes surface orientation for acoustic reflection modeling
 * ═══════════════════════════════════════════════════════════ */

/**
 * Estimate surface normal at a point using PCA on local neighborhood.
 * Critical for computing acoustic reflection angles.
 */
void lidar_estimate_normals(
    const ss_point_cloud_t* cloud,
    float* normals_x, float* normals_y, float* normals_z,
    int k_neighbors
) {
    for (int i = 0; i < cloud->count; i++) {
        const ss_point3d_t* p = &cloud->points[i];
        
        /* Find k nearest neighbors */
        float cx = 0, cy = 0, cz = 0;
        int count = 0;
        
        for (int j = 0; j < cloud->count && count < k_neighbors; j++) {
            if (i == j) continue;
            const ss_point3d_t* q = &cloud->points[j];
            float d = (p->x - q->x) * (p->x - q->x) +
                      (p->y - q->y) * (p->y - q->y) +
                      (p->z - q->z) * (p->z - q->z);
            if (d < 0.25f) { /* Within 0.5m radius */
                cx += q->x - p->x;
                cy += q->y - p->y;
                cz += q->z - p->z;
                count++;
            }
        }
        
        if (count < 3) {
            /* Not enough neighbors — default to vertical surface */
            normals_x[i] = 0.0f;
            normals_y[i] = 0.0f;
            normals_z[i] = 1.0f;
            continue;
        }
        
        /* Simplified PCA: use cross product of covariance eigenvectors */
        float nx = cy * 1.0f - cz * 0.0f;
        float ny = cz * 0.0f - cx * 1.0f;
        float nz = cx * 0.0f - cy * 0.0f;
        
        /* Normalize */
        float mag = sqrtf(nx*nx + ny*ny + nz*nz);
        if (mag > 0.001f) {
            normals_x[i] = nx / mag;
            normals_y[i] = ny / mag;
            normals_z[i] = nz / mag;
        } else {
            normals_x[i] = 0.0f;
            normals_y[i] = 0.0f;
            normals_z[i] = 1.0f;
        }
    }
}

/* ═══════════════════════════════════════════════════════════
 * POWER MANAGEMENT
 * ═══════════════════════════════════════════════════════════ */

void lidar_set_power_mode(uint8_t mode) {
    switch (mode) {
        case 0: /* Off */
            lidar_reg_write(LIDAR_REG_CTRL, 0);
            lidar_state.left_active = false;
            lidar_state.right_active = false;
            break;
        case 1: /* Single sensor (power save) */
            lidar_state.left_active = true;
            lidar_state.right_active = false;
            break;
        case 2: /* Full (both sensors) */
            lidar_state.left_active = true;
            lidar_state.right_active = true;
            break;
    }
}
